# Viola Home Design — nuovo sito

Sito statico per **Viola Home Design**, negozio di bomboniere, liste nozze, articoli da regalo e casalinghi in Via Nazionale Appia a Casagiove (CE), all'uscita A1 Caserta Nord. Il negozio oggi non ha un sito. Il sito non ha e-commerce né area clienti: porta le persone a scrivere su WhatsApp, chiamare o venire in negozio.
Brief e scelte di progetto: [PROMPT.md](PROMPT.md).

## 1. Stato al 12/10/2026

Sono completate le **fasi 0, 1 e 2** del PROMPT §17: raccolta dati, fondamenta e hero, home completa. Le pagine interne (fase 3) non esistono ancora, quindi i link verso `/bomboniere/…`, `/lista-nozze/`, `/recensioni/`, `/privacy-policy/` ecc. per ora portano alla 404.

**La home, dall'alto in basso** (PROMPT §7):

| Sezione | Cosa fa | Dati |
|---|---|---|
| Hero «Il nastro viola» | vetrina ad arco con 4 foto e cartellino, nastro che si disegna, fiocco, confetti, stato «Aperto ora», badge 5,0 | `config.json`, `eroe.mjs` |
| Avvisi | barra a tempo (vuota finché non ci sono avvisi) | `data/avvisi.json` |
| Per ogni occasione | 4 card ad arco (matrimonio, battesimo, comunione, compleanno) + lista nozze e casa | `data/occasioni.json` (solo `pubblica: true`) |
| **Configuratore** | 4 passi (occasione, stile, budget, dettagli), riepilogo «biglietto» | `data/configuratore.json` |
| **Recensioni** | sezione scura: 5,0, barre, carosello di 9 recensioni con testo e risposte della titolare, nota di trasparenza | `data/recensioni.json` |
| Lista nozze | 3 passi e WhatsApp | — |
| Casa e idee regalo | 23 oggetti con filtri per categoria, lightbox, «Chiedi info» su WhatsApp | `data/vetrina.json` |
| Perché da Viola + I tempi giusti | 6 punti e timeline con calcolo «ordina entro» | — |
| Chi siamo, FAQ, Dove siamo, Instagram, chiusura | | `data/faq.json`, `config.json` |

**Configuratore**:
- un'occasione scelta col dito o col mouse fa avanzare da sola, con la tastiera no;
- dalle card delle occasioni si arriva al configuratore con l'occasione già scelta;
- funziona anche con il link `/?occasione=matrimonio#configuratore`, utile per i post social;
- lo stato resta salvato se si ricarica la pagina (memoria locale del browser, nessun dato al server);
- il riepilogo calcola «Ordina entro» (data − 30 giorni) e «pronte verso» (data − 7);
- l'invio passa da WhatsApp, email o «Preferisco venire in negozio»;
- senza JavaScript al suo posto compare un elenco di link WhatsApp, uno per occasione.

**Mappa** (sezione «Dove siamo»):
- al caricamento della pagina il sito mostra un'immagine locale generata con `tools/mappa-statica.mjs` (© OpenStreetMap) e non contatta nessun dominio terzo;
- la mappa Google si carica solo dopo il clic su «Carica la mappa interattiva», che salva la scelta nel cookie tecnico `vhd_consenso` per 6 mesi;
- il banner cookie completo arriva in fase 4.

**Verifiche fatte** (server di prova con gzip e CSP, Chrome headless):

| Controllo | Esito |
|---|---|
| Lighthouse mobile | Prestazioni **99** · Accessibilità 97 · Best practices 100 · SEO 100 — FCP 1,1 s, LCP 2,1 s (il titolo), CLS 0 |
| Lighthouse desktop | Prestazioni **100** · Accessibilità 97 · Best practices 100 · SEO 100 |
| Accessibilità 97 | l'unico rilievo è il **contrasto del bianco sul verde WhatsApp #25D366** (2:1), scelta voluta da Christian |
| Impaginazione a 320, 375, 768, 1024 e 1440 px | nessuno scroll orizzontale, target tattili ≥ 44 px, nessuna immagine rotta, nessun errore in console |
| Test delle interazioni | 24/24 su configuratore, galleria, lightbox, tempi, recensioni e mappa |

Il dettaglio dei test delle interazioni:
- **configuratore**: avanzamento automatico, contatore, «ordina entro», testo WhatsApp completo, email, stato salvato dopo la ricarica, «Ricomincia», errore se manca la scelta, card occasione che preimposta;
- **galleria**: 6 oggetti su mobile + «Mostra tutte», filtro Piante, lightbox (apertura, freccia da tastiera, Esc);
- **altro**: avviso «tempi stretti» sotto i 30 giorni, «Leggi tutto» sulle recensioni lunghe;
- **mappa**: nessuna richiesta a terzi finché non si clicca, poi iframe Google e cookie di consenso.

Pesi della home (gzip):
- HTML 22 KB, CSS 13 KB, JS 9 KB;
- immagini sotto la piega con caricamento differito;
- foto 2–4 della vetrina caricate dopo l'evento `load`.

Schermate in `anteprime/`:
- `home-320/375/768/1024/1440`;
- `configuratore-riepilogo-390`, `lightbox-390`;
- quelle della fase 1.

## 2. Dati raccolti in fase 0 (rispetto al PROMPT)

| Dato | Valore | Fonte | Note |
|---|---|---|---|
| Orari | **Lun–ven 9:30–13 · 16:30–20 · Sab 9–13 · 16:30–20 · Dom chiuso** | Google Maps, 12/10/2026 | Matrimonio.com dice 9–13 / 16–20: vale Google, più recente. Il lunedì mattina risulta aperto. Da far confermare comunque |
| Coordinate | 41.0734867, 14.3024223 | Google Maps | |
| Place ID | `ChIJeYrgcqNVOhMRN-uoFO-F86g` (CID 12174221479602875191) | ricavato dall'ID della scheda e verificato su Maps | serve per il link «scrivi una recensione» |
| Recensioni Google | **5,0 su 10**, tutte a 5 stelle: 7 con testo, 3 solo stelle | Google Maps | Google mostra date relative («5 mesi fa»): il campo `periodo` è approssimativo |
| Recensioni Matrimonio.com | 5,0 su 2 (Mariasilvia, Giusy, gennaio 2023) | Matrimonio.com | Il testo completo di Giusy è nei dati strutturati della pagina |
| **Battesimo e comunione** | confermati | recensione di Leonardo V. («io ne ho usufruito per il battesimo e la comunione dei miei figli») | |
| Compleanno | confermato | post Facebook del 07/10/2026 | |
| Nascita, cresima, laurea | **non confermati** | — | Non compaiono sul sito finché il negozio non li conferma |
| Gioielli | probabile nuova linea | Instagram 07/10/2026 (collane in scatoline) | da confermare |
| Titolare | Giampiera («Piera») | recensioni Matrimonio.com | Il cognome e il consenso a nominarla sono da chiedere |
| Civico | 298 (Google) / 300 (Facebook, Matrimonio.com) | — | Sul sito oggi è 298, evidenziato in giallo |
| Dominio | **violahomedesign.it libero** | whois.nic.it, 12/10/2026 | Facebook lo indica ancora come sito: va registrato subito a nome del cliente |

## 3. Comandi

**Anteprima in autonomia**: doppio clic su `Avvia anteprima.command` nella cartella del progetto.
1. Rigenera il sito.
2. Apre il browser su http://127.0.0.1:8899.
3. Per fermarla basta chiudere la finestra del Terminale.

Dopo una modifica a `src/` si rilancia con un altro doppio clic, che spegne da solo l'anteprima precedente.

**Anteprima online su GitHub Pages**:
- `.github/workflows/pages.yml` rigenera e pubblica il sito a ogni aggiornamento del repo. Si attiva una volta sola da Settings → Pages → Source: «GitHub Actions».
- Il sito finisce in una sottocartella (`https://utente.github.io/nome-repo/`): per questo il build prefissa i percorsi con `--base`.
- Con `--anteprima` ogni pagina ha `noindex` e il `robots.txt` chiude tutto: Google non indicizza la bozza.
- Il `.htaccess` lì non vale: niente CSP né header di sicurezza, e `/recensione` funziona con una pagina di reindirizzamento.

```bash
node tools/build.mjs                      # genera sito/ da src/ (meno di 1 s)
node tools/build.mjs --pubblica           # come sopra, ma si ferma se restano dati [DA CONFERMARE]
./tools/anteprima.sh                      # build + copia nello scratchpad servito dall'anteprima (config «viola-sito», porta 8890)
node tools/server.mjs sito 8890           # server come l'hosting: gzip, CSP, 404, redirect /recensione
node tools/schermate.mjs http://127.0.0.1:8890 anteprime / --larghezze=375,768,1440 [--ridotto] [--segmenti=14]
/usr/bin/python3 tools/immagini.py        # ritaglia e converte in AVIF/WebP le foto di sorgenti/ (hero, card, vetrina, Instagram)
node tools/mappa-statica.mjs              # rigenera la mappa statica (MapLibre del progetto Studio Russo + OpenFreeMap)
```

- **iCloud**: `fs.cpSync` sulla cartella iCloud impiega più di un minuto (usa la clonazione dei file), per questo il build copia gli asset «a mano».
- **Anteprima**: il pannello non legge iCloud. `anteprima.sh` copia `sito/` e `server.mjs` nello scratchpad della sessione. In una nuova sessione aggiorna il percorso in `tools/anteprima.sh` (variabile `ANTEPRIMA`) e nella config `viola-sito` di `.claude/launch.json`.
- **Lighthouse e potrace** sono installati fuori dal progetto (scratchpad, `nm/`): servono solo per le verifiche e per rigenerare il logo.

## 4. Logo

Non esiste un file vettoriale del logo, e le due fonti disponibili sono imperfette:
- la **foto profilo di Facebook** (257 px) è nitida ma ritagliata: la «V» e la «a» sono tagliate;
- l'**insegna sulla facciata** (Google Maps, 2023) è intera ma sfocata e ha l'ombra di una lampada.

`tools/logo/componi.py` allinea l'insegna sulla foto profilo per correlazione (scala 4,35×) e completa i bordi mancanti. Poi `tools/logo/traccia.cjs` vettorializza con potrace:

```bash
/usr/bin/python3 tools/logo/componi.py <cartella>
NODE_PATH=<cartella con potrace> node tools/logo/traccia.cjs <cartella>
```

- **«Home Design» è composto nel font Great Vibes** (OFL, in `tools/logo/`), che coincide con quello del logo. A 15 px di altezza il ricalco veniva spezzato.
- «Viola» e il fregio sono ricalcati. Sono fedeli, ma le linee più sottili del fregio sono un po' più spesse dell'originale e i due fiorellini lilla piccoli sono semplificati.
- **Va fatto approvare al cliente**. Se esiste il file originale (dal grafico o da chi ha fatto l'insegna), va sostituito a questi due SVG.

## 5. Foto

- La **vetrina della hero** usa 4 foto caricate dal negozio su Matrimonio.com nel 2023: scatola con fiori in porcellana, statuine per la comunione, alberelli di limoni, bouquet in ceramica. Sono senza watermark, 1024 px.
- Due foto belle sono state **escluse** perché sulle targhette si leggono i nomi degli sposi.
- **Serve l'OK del negozio** all'uso delle foto (sono sue) e, se possibile, gli originali a risoluzione piena e uno shooting (PROMPT §11).
- Sulle foto si leggono alcuni marchi: **EGAN, Stone Italia, Paola Rolando Creazioni, Gli Alberelli, «N Capodimonte»**. Sul sito non ne è citato nessuno finché il negozio non conferma che li tratta e che si possono nominare.
- Le foto con persone recensite su Google (caricate dai clienti) e la foto Street View della facciata **non** vanno usate sul sito.

## 6. Struttura

```
viola-home-design-sito/
  PROMPT.md  README.md
  src/
    config.json           dati del negozio (indirizzo, orari, contatti, link Google, social, dati legali)
    data/                 recensioni, occasioni, configuratore (stili, budget, extra), vetrina, faq, avvisi
    lib/                  dati.mjs, ui.mjs (componenti), layout.mjs (testata/menu/piede), eroe.mjs (hero),
                          sezioni-negozio.mjs (occasioni, configuratore, lista nozze, vetrina, perché/tempi),
                          sezioni-fiducia.mjs (recensioni, chi siamo, FAQ, dove siamo, Instagram, chiusura, avvisi)
    pagine/               una pagina = un modulo (export meta + default)
    assets/               css/stile.css, js/app.js, icone.svg, fonts/, img/
    radice/               file copiati nella radice del sito (favicon)
    htaccess.txt          → sito/.htaccess (con hash CSP)
  sito/                   output pronto da caricare (non modificare a mano)
  tools/                  build, server di prova, schermate, immagini, logo/
  sorgenti/               matrimonio/, instagram/ (+ indice.json), facebook/, google/
  anteprime/              schermate di verifica
```

**Modifiche frequenti**:
- **orari**: `src/config.json` → `orari.settimana`, che alimenta il piè di pagina, lo stato «Aperto ora» e il menu;
- **recensioni**: `src/data/recensioni.json`, copiando il testo identico. Il riepilogo 5,0 arriva da `config.json` → `google.media/totale`;
- **foto della vetrina in hero**: `SLIDE` in `src/lib/eroe.mjs` + `FOTO` in `tools/immagini.py`. Le etichette devono restare vere.
- **oggetti di «Casa e idee regalo»**: una voce in `src/data/vetrina.json` (foto in `sorgenti/`), poi `tools/immagini.py` e `tools/build.mjs`.
- **avvisi** (Natale, aperture straordinarie): `src/data/avvisi.json`, con date `dal`/`al`; dopo la scadenza si nascondono da soli.

## 7. Da confermare col negozio

Le voci evidenziate in giallo nel sito sono contate dal build: oggi sono 5 (civico ×2, nome della titolare, ragione sociale, P.IVA).

1. **Civico** 298 o 300.
2. **Ragione sociale, P.IVA**, sede legale, PEC.
3. **Orari** (quelli di Google) e chiusure stagionali.
4. **WhatsApp**: il 334 981 8211 è su WhatsApp? Tutti i pulsanti lo danno per scontato.
5. **Occasioni**: nascita, cresima, laurea, anniversari? Si attivano con `pubblica: true` in `data/occasioni.json`.
6. **Fasce di budget** del configuratore (3–5 €, 5–10 €, 10–20 €, oltre 20 €): sono indicative. L'unico dato pubblico è «da 3 €».
7. **FAQ** (`data/faq.json`): le risposte vengono dalle FAQ del negozio su Matrimonio.com e vanno fatte rileggere.
8. **Tempi**: «almeno 1 mese prima» e «pronte circa 1 settimana prima» vengono da Matrimonio.com (`anticipoGiorni`, `prontoGiorniPrima`).
9. **Lista nozze**: come scelgono il regalo gli invitati (in negozio, a distanza)?
10. **Consegna a domicilio** e spedizioni: zone, costi, tempi.
11. **Marchi** visibili nelle foto (EGAN e Stone Italia si leggono bene in due foto della vetrina): si possono mostrare?
12. **Titolare**: nome completo, consenso a nominarla, eventuale foto.
13. **Foto**: OK all'uso di quelle di Matrimonio.com e Instagram, originali, shooting. La foto della card «Compleanno» (collane, dal video Instagram del 07/10/2026) è solo 356 px.
14. **Logo**: approvazione del ridisegno o file originale.
15. Gioielli: è una nuova linea?

**Fuori dal sito, subito**:
- registrare `violahomedesign.it`;
- su Google, nome della scheda senza parole chiave e civico corretto;
- su Facebook, togliere «Opening Soon» e attivare le recensioni.

## 8. Prossimo passo: fase 3

Pagine interne (PROMPT §5):
- hub `/bomboniere/` e le 4 pagine delle occasioni attive;
- `/lista-nozze/`, `/casa-e-regali/`, `/recensioni/` (tutte le recensioni, filtri, nota di trasparenza);
- `/chi-siamo/`, `/contatti/`, `/domande-frequenti/`, 404.

Poi la fase 4: banner cookie e informative, JSON-LD, sitemap, llms.txt, favicon e icone, immagine di condivisione.
