// Genera il sito statico in sito/ partendo da src/.
//
//   node tools/build.mjs            → build completo
//   node tools/build.mjs --pubblica → come sopra, ma si ferma se restano dati [DA CONFERMARE]
//
// Nessuna dipendenza: solo Node ≥ 20.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const RADICE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.join(RADICE, 'src');
const OUT = path.join(RADICE, 'sito');
const pubblica = process.argv.includes('--pubblica');

const ui = await import(pathToFileURL(path.join(SRC, 'lib', 'ui.mjs')));
const { documento, SCRIPT_JS } = await import(pathToFileURL(path.join(SRC, 'lib', 'layout.mjs')));

const hash = (buf) => crypto.createHash('sha256').update(buf).digest('hex').slice(0, 10);
const scrivi = (rel, contenuto) => { const f = path.join(OUT, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, contenuto); };

// 1. pulizia e copia degli asset.
// Copia «a mano» (lettura + scrittura): fs.cpSync su iCloud usa la clonazione dei file e impiega oltre un minuto.
const copia = (da, a) => {
  fs.mkdirSync(a, { recursive: true });
  for (const d of fs.readdirSync(da, { withFileTypes: true })) {
    if (d.name === '.DS_Store') continue;
    const s = path.join(da, d.name), o = path.join(a, d.name);
    if (d.isDirectory()) copia(s, o); else fs.writeFileSync(o, fs.readFileSync(s));
  }
};
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
copia(path.join(SRC, 'assets'), path.join(OUT, 'assets'));
if (fs.existsSync(path.join(SRC, 'radice'))) copia(path.join(SRC, 'radice'), OUT);

// 2. versioni (cache-busting) di tutti gli asset
const elenca = (dir, base = '') => fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? elenca(path.join(dir, d.name), `${base}${d.name}/`) : [`${base}${d.name}`]));
for (const rel of elenca(path.join(OUT, 'assets'))) ui.versioni[rel] = hash(fs.readFileSync(path.join(OUT, 'assets', rel)));
// il CSS richiama font e sprite con url relativi: aggiungo la versione anche lì
const css = path.join(OUT, 'assets', 'css', 'stile.css');
fs.writeFileSync(css, fs.readFileSync(css, 'utf8').replace(/url\(\.\.\/(fonts\/[^)]+\.woff2)\)/g, (m, rel) => `url(../${rel}?v=${ui.versioni[rel]})`));
ui.versioni['css/stile.css'] = hash(fs.readFileSync(css));

// 3. pagine
const pagine = [];
for (const file of fs.readdirSync(path.join(SRC, 'pagine')).filter((f) => f.endsWith('.mjs')).sort()) {
  const mod = await import(pathToFileURL(path.join(SRC, 'pagine', file)));
  const meta = mod.meta;
  const html = documento(meta, mod.default(), { testa: meta.testa || '' });
  const rel = meta.percorso.endsWith('.html') ? meta.percorso.slice(1) : path.join(meta.percorso.slice(1), 'index.html');
  scrivi(rel, html);
  pagine.push({ meta, rel, html });
}

// 4. .htaccess con l'hash dello script in linea per la CSP
const hashScript = crypto.createHash('sha256').update(SCRIPT_JS).digest('base64');
scrivi('.htaccess', fs.readFileSync(path.join(SRC, 'htaccess.txt'), 'utf8').replace('{{HASH_SCRIPT}}', `'sha256-${hashScript}'`));

// 5. controllo dei segnaposto [DA CONFERMARE]
let segnaposto = 0;
const dove = {};
for (const p of pagine) {
  const n = (p.html.match(/data-da-confermare/g) || []).length;
  if (n) { segnaposto += n; dove[p.meta.percorso] = n; }
}
const peso = (rel) => (fs.statSync(path.join(OUT, rel)).size / 1024).toFixed(1);
console.log(`✓ ${pagine.length} pagine · CSS ${peso('assets/css/stile.css')} KB · JS ${peso('assets/js/app.js')} KB (non compressi)`);
if (segnaposto) {
  console.log(`⚠ ${segnaposto} dati [DA CONFERMARE] visibili:`, dove);
  if (pubblica) { console.error('✗ Build di pubblicazione interrotta: completa i dati mancanti (README).'); process.exit(1); }
}
