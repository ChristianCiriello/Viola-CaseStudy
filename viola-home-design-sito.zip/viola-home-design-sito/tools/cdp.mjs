// Piccolo client per Chrome headless via DevTools Protocol, senza dipendenze.
// Usato da grafiche.mjs, shots.mjs e check-ui.mjs.
//
//   const chrome = await avviaChrome();
//   const pagina = await chrome.nuovaPagina();
//   await pagina.vai('http://127.0.0.1:8820/');
//   await pagina.js('document.title');
//   await chrome.chiudi();
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

export const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
export const attendi = (ms) => new Promise((r) => setTimeout(r, ms));

// webgl: GPU software (SwiftShader) per provare la mappa. Rallenta molto il disegno: per misurare le prestazioni usare webgl: false.
export async function avviaChrome({ porta = 9300 + Math.floor(Math.random() * 500), webgl = true } = {}) {
  const profilo = fs.mkdtempSync(path.join(os.tmpdir(), 'russo-chrome-'));
  const processo = spawn(CHROME, [
    '--headless=new', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check', '--force-color-profile=srgb',
    ...(webgl ? ['--enable-unsafe-swiftshader', '--use-angle=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] : []),
    `--remote-debugging-port=${porta}`, `--user-data-dir=${profilo}`, 'about:blank',
  ], { stdio: 'ignore' });

  let pronto = false;
  for (let i = 0; i < 80 && !pronto; i++) {
    try { await (await fetch(`http://127.0.0.1:${porta}/json/version`)).json(); pronto = true; } catch { await attendi(150); }
  }
  if (!pronto) throw new Error('Chrome non risponde');

  const chiudi = async () => {
    try { processo.kill('SIGKILL'); } catch { /* già chiuso */ }
    await attendi(200);
    try { fs.rmSync(profilo, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch { /* temporanea */ }
  };
  process.on('exit', () => { try { processo.kill('SIGKILL'); } catch { /* */ } });

  async function nuovaPagina() {
    const target = await (await fetch(`http://127.0.0.1:${porta}/json/new?about:blank`, { method: 'PUT' })).json();
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((ok, ko) => { ws.onopen = ok; ws.onerror = ko; });
    let seq = 0;
    const attese = new Map();
    const ascoltatori = new Map();
    const console_ = [];
    ws.onmessage = (m) => {
      const d = JSON.parse(m.data);
      if (d.id && attese.has(d.id)) { attese.get(d.id)(d); attese.delete(d.id); }
      if (d.method) {
        (ascoltatori.get(d.method) || []).forEach((fn) => fn(d.params));
        if (d.method === 'Runtime.exceptionThrown') console_.push({ tipo: 'eccezione', testo: d.params.exceptionDetails.exception?.description || d.params.exceptionDetails.text });
        if (d.method === 'Runtime.consoleAPICalled') console_.push({ tipo: d.params.type, testo: d.params.args.map((a) => a.value ?? a.description ?? '').join(' ') });
        if (d.method === 'Log.entryAdded') console_.push({ tipo: d.params.entry.level, testo: `${d.params.entry.source}: ${d.params.entry.text} ${d.params.entry.url || ''}` });
      }
    };
    const invia = (method, params = {}) => new Promise((ok, ko) => {
      const id = ++seq;
      attese.set(id, (d) => (d.error ? ko(new Error(`${method}: ${d.error.message}`)) : ok(d.result)));
      ws.send(JSON.stringify({ id, method, params }));
    });
    const su = (evento, fn) => { ascoltatori.set(evento, [...(ascoltatori.get(evento) || []), fn]); };
    await invia('Page.enable');
    await invia('Runtime.enable');
    await invia('Log.enable');
    await invia('Network.enable');

    const pagina = {
      invia, su, console: console_,
      async js(espressione) {
        const r = await invia('Runtime.evaluate', { expression: espressione, awaitPromise: true, returnByValue: true, userGesture: true });
        if (r.exceptionDetails) throw new Error(`JS: ${(r.exceptionDetails.exception?.description || r.exceptionDetails.text).slice(0, 500)}`);
        return r.result.value;
      },
      async vai(url, { attesa = 'load', timeout = 30000 } = {}) {
        const caricata = new Promise((ok) => {
          const t = setTimeout(ok, timeout);
          su(attesa === 'load' ? 'Page.loadEventFired' : 'Page.domContentEventFired', () => { clearTimeout(t); ok(); });
        });
        const r = await invia('Page.navigate', { url });
        await caricata;
        return r;
      },
      async viewport(larghezza, altezza, { mobile = false, scala = 1 } = {}) {
        await invia('Emulation.setDeviceMetricsOverride', { width: larghezza, height: altezza, deviceScaleFactor: scala, mobile });
        await invia('Emulation.setTouchEmulationEnabled', { enabled: mobile });
      },
      async aspetta(espressione, { timeout = 15000, intervallo = 100 } = {}) {
        const fine = Date.now() + timeout;
        while (Date.now() < fine) {
          try { if (await pagina.js(espressione)) return true; } catch { /* la pagina sta cambiando */ }
          await attendi(intervallo);
        }
        throw new Error(`Timeout in attesa di: ${espressione}`);
      },
      // Clic «vero» del mouse: porta l'elemento al centro, aspetta che smetta di muoversi (scorrimenti
      // fluidi in corso) e verifica che sotto il puntatore ci sia proprio quell'elemento, non un overlay.
      async clic(selettore) {
        const sel = JSON.stringify(selettore);
        const esiste = await pagina.js(`(() => { const el = document.querySelector(${sel}); if (!el) return false; el.scrollIntoView({ block: 'center', behavior: 'instant' }); return true; })()`);
        if (!esiste) throw new Error(`Elemento non trovato: ${selettore}`);
        let box = null;
        for (let i = 0; i < 40; i++) {
          const r = await pagina.js(`(() => { const el = document.querySelector(${sel}); const r = el.getBoundingClientRect(); if (r.top < 0 || r.bottom > innerHeight) el.scrollIntoView({ block: 'center', behavior: 'instant' }); const q = el.getBoundingClientRect(); return { x: q.left + q.width / 2, y: q.top + q.height / 2 }; })()`);
          if (box && Math.abs(box.x - r.x) < 0.5 && Math.abs(box.y - r.y) < 0.5) break;
          box = r;
          await attendi(60);
        }
        const colpito = await pagina.js(`(() => { const el = document.querySelector(${sel}); const h = document.elementFromPoint(${box.x}, ${box.y}); return !h ? 'niente' : (el === h || el.contains(h) || h.contains(el) && h.tagName === 'LABEL') ? '' : h.outerHTML.slice(0, 140); })()`);
        if (colpito) throw new Error(`Il clic su ${selettore} finirebbe su un altro elemento: ${colpito}`);
        for (const type of ['mousePressed', 'mouseReleased']) {
          await invia('Input.dispatchMouseEvent', { type, x: box.x, y: box.y, button: 'left', clickCount: 1 });
        }
      },
      async tasto(key, code = key, keyCode = 0) {
        await invia('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: keyCode });
        await invia('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: keyCode });
      },
      async scrivi(selettore, testo) {
        await pagina.js(`(() => { const el = document.querySelector(${JSON.stringify(selettore)}); el.focus(); el.select?.(); })()`);
        await invia('Input.insertText', { text: testo });
      },
      async schermata(file, { paginaIntera = false, tipo = 'jpeg', qualita = 85, clip = null } = {}) {
        let params = { format: tipo, captureBeyondViewport: paginaIntera };
        if (tipo === 'jpeg') params.quality = qualita;
        if (paginaIntera) {
          const m = await invia('Page.getLayoutMetrics');
          params.clip = { x: 0, y: 0, width: m.cssContentSize.width, height: m.cssContentSize.height, scale: 1 };
        }
        if (clip) { params.clip = { ...clip, scale: clip.scale || 1 }; params.captureBeyondViewport = clip.y + clip.height > 0; }
        const r = await invia('Page.captureScreenshot', params);
        fs.writeFileSync(file, Buffer.from(r.data, 'base64'));
        return file;
      },
      chiudi: () => ws.close(),
    };
    return pagina;
  }

  return { nuovaPagina, chiudi, porta };
}
