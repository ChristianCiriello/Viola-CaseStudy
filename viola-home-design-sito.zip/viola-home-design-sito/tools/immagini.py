#!/usr/bin/python3
"""Genera le foto del sito in AVIF e WebP, in più larghezze e senza metadati.

    /usr/bin/python3 tools/immagini.py

Legge da sorgenti/ (foto del negozio da Matrimonio.com, Instagram, Facebook) e scrive in src/assets/img/
file come «eroe-scatola-600.avif» e «eroe-scatola-600.webp». Scrive anche tools/immagini.json con
le misure reali, che il build usa per width/height e srcset.

Ritaglio: un rapporto (es. 4:5) centrato sul punto focale (fx, fy), in frazioni dell'immagine.
"""
import sys, json
from pathlib import Path
sys.path.append(str(Path.home() / 'Library/Python/3.9/lib/python/site-packages'))
from PIL import Image, ImageOps

QUI = Path(__file__).resolve().parent
SORG = QUI.parent / 'sorgenti'
DEST = QUI.parent / 'src' / 'assets' / 'img'

# nome, sorgente, larghezze, rapporto, fuoco
FOTO = [
    # vetrina ad arco della hero (4:5): la prima è l'immagine LCP
    ('eroe-scatola', 'matrimonio/file-1674584956985.jpg', (400, 600, 720, 819), (4, 5), (0.56, 0.5)),
    ('eroe-comunione', 'matrimonio/file-1674584926692.jpg', (400, 600, 720, 819), (4, 5), (0.42, 0.5)),
    ('eroe-limoni', 'matrimonio/file-1674930850420.jpg', (400, 600, 720, 819), (4, 5), (0.52, 0.5)),
    ('eroe-bouquet', 'matrimonio/img-0914.jpg', (400, 600, 720, 900), (4, 5), (0.47, 0.52)),
    # card «Per ogni occasione» (4:5) e card larghe (lista nozze, casa)
    ('occ-matrimonio', 'matrimonio/file-1674585045622.jpg', (360, 560), (4, 5), (0.5, 0.5)),
    ('occ-battesimo', 'matrimonio/file-1674920795992.jpg', (360, 560), (4, 5), (0.5, 0.55)),
    ('occ-compleanno', 'instagram/2026-10-07_video.jpg', (356,), (4, 5), (0.5, 0.5)),
    ('occ-lista', 'instagram/2026-09-11_foto.jpg', (400, 512), (4, 5), (0.5, 0.5)),
    ('occ-casa', 'matrimonio/file-1674930861582.jpg', (400, 640), (4, 5), (0.5, 0.55)),
    # stili del configuratore (1:1)
    ('stile-eleganza', 'matrimonio/file-1674585001286.jpg', (200, 360), (1, 1), (0.5, 0.45)),
    ('stile-natura', 'matrimonio/file-1674585028389.jpg', (200, 360), (1, 1), (0.5, 0.5)),
    ('stile-profumo', 'matrimonio/file-1676368887046.jpg', (200, 360), (1, 1), (0.5, 0.5)),
    ('stile-gusto', 'matrimonio/file-1674921443370.jpg', (200, 360), (1, 1), (0.5, 0.5)),
    ('stile-portafortuna', 'matrimonio/file-1674585077985.jpg', (200, 360), (1, 1), (0.5, 0.45)),
    ('stile-design', 'matrimonio/file-1674571100080.jpg', (200, 360), (1, 1), (0.5, 0.5)),
    # lista nozze e chi siamo
    ('lista-living', 'instagram/2026-09-06_foto.jpg', (480, 640), (4, 3), (0.5, 0.5)),
    ('chi-siamo-negozio', 'facebook/copertina-ceramiche-s1875x1250.jpg', (600, 1000, 1400), (16, 9), (0.5, 0.0)),  # 16:9 dall'alto: esclude il watermark in basso a destra
]

# vetrina «Casa e idee regalo»: dimensioni e ritagli letti da src/data/vetrina.json
def voci_vetrina():
    dati = json.loads((QUI.parent / 'src' / 'data' / 'vetrina.json').read_text())
    for v in dati['voci']:
        yield (f"vetrina-{v['id']}", v['sorgente'], (360, 720), tuple(v.get('rapporto', (1, 1))), tuple(v.get('fuoco', (0.5, 0.5))))

# striscia Instagram (1:1)
INSTAGRAM = ['2026-09-28', '2026-09-16', '2026-09-14', '2026-09-04', '2026-08-24', '2026-08-31']
def voci_instagram():
    for d in INSTAGRAM:
        yield (f'ig-{d}', f'instagram/{d}_foto.jpg', (240, 480), (1, 1), (0.5, 0.5))


def ritaglia(im, rapporto, fuoco):
    w, h = im.size
    rw, rh = rapporto
    fx, fy = fuoco
    if w / h > rw / rh:
        nw = round(h * rw / rh)
        x = min(max(round(fx * w - nw / 2), 0), w - nw)
        return im.crop((x, 0, x + nw, h))
    nh = round(w * rh / rw)
    y = min(max(round(fy * h - nh / 2), 0), h - nh)
    return im.crop((0, y, w, y + nh))


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    indice = {}
    for nome, sorgente, larghezze, rapporto, fuoco in [*FOTO, *voci_vetrina(), *voci_instagram()]:
        im = ImageOps.exif_transpose(Image.open(SORG / sorgente)).convert('RGB')
        im = ritaglia(im, rapporto, fuoco)
        w, h = im.size
        uscite = []
        for lw in larghezze:
            lw = min(lw, w)
            lh = round(h * lw / w)
            r = im.resize((lw, lh), Image.LANCZOS)
            r.save(DEST / f'{nome}-{lw}.webp', 'WEBP', quality=78, method=6)
            r.save(DEST / f'{nome}-{lw}.avif', 'AVIF', quality=60)
            uscite.append({'w': lw, 'h': lh, 'kb_avif': round((DEST / f'{nome}-{lw}.avif').stat().st_size / 1024)})
        indice[nome] = uscite
        print(f'✓ {nome}: ' + ', '.join(f"{u['w']}×{u['h']} {u['kb_avif']}KB" for u in uscite))
    (QUI / 'immagini.json').write_text(json.dumps(indice, indent=1) + '\n')


if __name__ == '__main__':
    main()
