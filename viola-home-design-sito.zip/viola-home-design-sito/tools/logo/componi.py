#!/usr/bin/python3
"""Ricompone il logo intero partendo da due fonti imperfette.

    /usr/bin/python3 tools/logo/componi.py <cartella-uscita>

- sorgenti/facebook/logo-profilo-s257x257.jpg: la più nitida, ma Facebook la ritaglia (la «V» e la «a» sono tagliate).
- sorgenti/google/facciata-insegna-2023.jpg: l'insegna sulla facciata, sfocata ma intera.

Allinea l'insegna sulla foto profilo (scala + spostamento, per correlazione delle parti nere), poi completa
i bordi mancanti con i pixel dell'insegna e scrive le maschere da vettorializzare (ingrandite 4×):
  nero.png  → lettering e fregio
  viola.png → fiori del fregio
"""
import sys, json
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter, ImageOps

QUI = Path(__file__).resolve().parent
SORG = QUI.parent.parent / 'sorgenti'
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
K = 4  # ingrandimento di lavoro

fb = Image.open(SORG / 'facebook' / 'logo-profilo-s257x257.jpg').convert('RGB')
fb = fb.resize((fb.width * K, fb.height * K), Image.LANCZOS)
F = np.asarray(fb).astype(float)

ins = Image.open(SORG / 'google' / 'facciata-insegna-2023.jpg').convert('RGB').crop((420, 420, 750, 600))
# l'insegna è grigio/bianca con un'ombra a destra: normalizzo con un fondo stimato (sfocatura ampia) → inchiostro scuro su bianco
g = np.asarray(ImageOps.grayscale(ins)).astype(float)
fondo = np.asarray(ImageOps.grayscale(ins).filter(ImageFilter.GaussianBlur(9))).astype(float)
fondo = np.maximum(fondo, np.asarray(ImageOps.grayscale(ins).filter(ImageFilter.MaxFilter(9))).astype(float))
norm = np.clip(g / np.maximum(fondo, 1) * 255, 0, 255)

# maschere d'inchiostro (solo lettering nero: escludo la fascia lilla e la riga nera in alto della foto profilo)
lum_f = F.mean(axis=2)
ink_f = (lum_f < 110).astype(float)
ink_f[: 42 * K, :] = 0
ink_f[: 58 * K, : 150 * K] = 0

def adatta(scala):
    w, h = round(ins.width * scala), round(ins.height * scala)
    n = np.asarray(Image.fromarray(norm.astype('uint8')).resize((w, h), Image.LANCZOS)).astype(float)
    return n, (n < 120).astype(float)

def correla(a, b):
    # correlazione incrociata via FFT di b su a (b più piccola o uguale)
    H, W = a.shape[0] + b.shape[0], a.shape[1] + b.shape[1]
    fa = np.fft.rfft2(a, (H, W)); fbb = np.fft.rfft2(b[::-1, ::-1], (H, W))
    c = np.fft.irfft2(fa * fbb, (H, W))
    i = np.unravel_index(np.argmax(c), c.shape)
    return c[i], (i[0] - b.shape[0] + 1, i[1] - b.shape[1] + 1)

migliore = None
for scala in np.arange(3.6, 5.4, 0.05):
    n, ink_s = adatta(scala)
    v, (dy, dx) = correla(ink_f, ink_s)
    v /= ink_s.sum() ** 0.5
    if not migliore or v > migliore[0]:
        migliore = (v, scala, dy, dx)
_, scala, dy, dx = migliore
print(f'allineamento: scala {scala:.2f}, spostamento ({dx}, {dy})')

# tela allargata: la foto profilo al centro, i margini mancanti presi dall'insegna allineata
SIN, DES = 70 * K, 40 * K
tela = np.full((fb.height, fb.width + SIN + DES, 3), 255.0)
n, _ = adatta(scala)
y0, x0 = dy, dx + SIN
ys, xs = slice(max(y0, 0), min(y0 + n.shape[0], tela.shape[0])), slice(max(x0, 0), min(x0 + n.shape[1], tela.shape[1]))
pezzo = n[ys.start - y0: ys.stop - y0, xs.start - x0: xs.stop - x0]
tela[ys, xs] = np.minimum(tela[ys, xs], pezzo[..., None].repeat(3, axis=2))
# dell'insegna servono solo le due finestre dove la foto profilo è tagliata (coda della «V» e chiusura della «a»):
# il resto (bordo ovale, ombra della lampada) va scartato
tieni = np.zeros(tela.shape[:2], bool)
tieni[110 * K: 190 * K, SIN - 7 * K: SIN] = True
tieni[150 * K: 178 * K, SIN + fb.width: SIN + fb.width + 3 * K] = True
fuori = np.ones(tela.shape[:2], bool); fuori[:, SIN: SIN + fb.width] = False
tela[fuori & ~tieni] = 255
# nelle finestre dell'insegna tengo solo l'inchiostro pieno (l'insegna è sfocata e ha ombre)
finestra = fuori & tieni
tela[finestra & (tela.mean(axis=2) > 95)] = 255
# sopra: la foto profilo con un bordo sfumato di 6 px verso l'insegna
alfa = np.ones((fb.height, fb.width))
for i in range(6 * K):
    a = i / (6 * K)
    alfa[:, i] = np.minimum(alfa[:, i], a); alfa[:, -1 - i] = np.minimum(alfa[:, -1 - i], a)
reg = tela[:, SIN: SIN + fb.width]
tela[:, SIN: SIN + fb.width] = reg * (1 - alfa[..., None]) + F * alfa[..., None]
# l'insegna non ha la fascia lilla né la riga nera: le tolgo anche dalla foto profilo
tela[: 42 * K, :] = 255
# la riga nera curva in alto a sinistra va da (0, 54) a (140, 27) nelle coordinate della foto profilo:
# tolgo i pixel scuri sopra quella linea (+ margine), senza toccare i riccioli del fregio più in basso
yy, xx = np.mgrid[0: tela.shape[0], 0: tela.shape[1]]
xf = (xx - SIN) / K
sopra_riga = (xf < 150) & (yy / K < 56 - 0.19 * np.clip(xf, 0, None))
tela[sopra_riga & (tela.mean(axis=2) < 200)] = 255

Image.fromarray(tela.astype('uint8')).save(OUT / 'composto.png')

# livelli: viola = blu nettamente sopra il rosso; nero = tutto il resto, come luminanza (niente soglia rigida:
# le linee sottili del fregio sopravvivono meglio, la soglia la applica potrace)
R, G, B = tela[..., 0], tela[..., 1], tela[..., 2]
viola = (B - R >= 14) & (B - G >= 16) & (tela.mean(axis=2) < 222)
lum = tela.mean(axis=2)
lum[viola] = 255
lum = np.clip((lum - 40) * 255 / (215 - 40), 0, 255)  # più contrasto: fondo bianco pieno, inchiostro nero pieno

# «Home Design» nella foto profilo è alto ~15 px: le linee sottili si perdono. Il font è Great Vibes (OFL):
# lo ricompongo con il font, alla stessa posizione e larghezza dell'originale.
riga = (slice(195 * K, 245 * K), slice(SIN + 40 * K, SIN + 240 * K))
inch = lum[riga] < 128
ys_, xs_ = np.nonzero(inch)
bx0, bx1, by0, by1 = xs_.min(), xs_.max(), ys_.min(), ys_.max()
print(f'«Home Design» originale: {bx1 - bx0}×{by1 - by0} px')
lum[riga] = 255
from PIL import ImageDraw, ImageFont
def disegna(corpo):
    f = ImageFont.truetype(str(QUI / 'GreatVibes-Regular.ttf'), corpo)
    tmp = Image.new('L', (int(corpo * 7), int(corpo * 2)), 255)
    ImageDraw.Draw(tmp).text((corpo // 4, corpo // 4), 'Home Design', font=f, fill=0)
    a = np.asarray(tmp); yy_, xx_ = np.nonzero(a < 128)
    return a[yy_.min(): yy_.max() + 1, xx_.min(): xx_.max() + 1]
corpo = 100
for _ in range(6):
    t = disegna(corpo); corpo = round(corpo * (bx1 - bx0 + 1) / t.shape[1])
t = disegna(corpo)
print(f'Great Vibes corpo {corpo}: {t.shape[1]}×{t.shape[0]} px')
oy, ox = riga[0].start + by0, riga[1].start + bx0
h, w = min(t.shape[0], lum.shape[0] - oy), min(t.shape[1], lum.shape[1] - ox)
lum[oy: oy + h, ox: ox + w] = np.minimum(lum[oy: oy + h, ox: ox + w], t[:h, :w])

Image.fromarray(lum.astype('uint8')).filter(ImageFilter.GaussianBlur(1.2)).save(OUT / 'nero.png')
Image.fromarray(np.where(viola, 0, 255).astype('uint8')).filter(ImageFilter.GaussianBlur(2.2)).save(OUT / 'viola.png')
colore = lambda m: '#%02x%02x%02x' % tuple(int(np.median(c[m])) for c in (R, G, B))
json.dump({'w': tela.shape[1], 'h': tela.shape[0], 'viola': colore(viola & (B > 150))}, open(OUT / 'info.json', 'w'))
print('scritto', OUT)
