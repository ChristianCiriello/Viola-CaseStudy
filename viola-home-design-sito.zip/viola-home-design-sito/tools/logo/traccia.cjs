// Traccia le maschere del logo (nero.png, viola.png prodotte da componi.py) con potrace e scrive gli SVG.
//
//   NODE_PATH=<cartella con potrace> node tools/logo/traccia.cjs <cartella-maschere>
//
// Uscite in src/assets/img/: logo-viola.svg (positivo) e logo-viola-negativo.svg (per fondi scuri).
const fs = require('fs');
const path = require('path');
const potrace = require('potrace');

const dir = process.argv[2];
const info = JSON.parse(fs.readFileSync(path.join(dir, 'info.json'), 'utf8'));
const DEST = path.resolve(__dirname, '..', '..', 'src', 'assets', 'img');

const traccia = (nome, turd) => new Promise((ok, ko) => {
  const p = new potrace.Potrace({ threshold: nome === 'nero' ? 150 : 140, turdSize: turd, optTolerance: 0.4, alphaMax: 1.05, optCurve: true, blackOnWhite: true });
  p.loadImage(path.join(dir, nome + '.png'), (e) => { if (e) return ko(e); ok(p.getPathTag('#000').match(/ d="([^"]+)"/)[1]); });
});

(async () => {
  const d = { nero: await traccia('nero', 40), viola: await traccia('viola', 12) };
  // riquadro calcolato dai punti dei tracciati
  const nums = Object.values(d).join(' ').match(/-?\d+(\.\d+)?/g).map(Number);
  const xs = nums.filter((_, i) => i % 2 === 0), ys = nums.filter((_, i) => i % 2 === 1);
  const pad = 8;
  const x0 = Math.floor(Math.min(...xs)) - pad, y0 = Math.floor(Math.min(...ys)) - pad;
  const x1 = Math.ceil(Math.max(...xs)) + pad, y1 = Math.ceil(Math.max(...ys)) + pad;
  const arrot = (s) => s.replace(/-?\d+\.\d+/g, (m) => String(Math.round(parseFloat(m))));
  const svg = (nero, viola) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0} ${y0} ${x1 - x0} ${y1 - y0}" role="img" aria-label="Viola Home Design">
<path fill="${viola}" fill-rule="evenodd" d="${arrot(d.viola)}"/>
<path fill="${nero}" fill-rule="evenodd" d="${arrot(d.nero)}"/>
</svg>
`;
  fs.writeFileSync(path.join(DEST, 'logo-viola.svg'), svg('#1e1a26', '#7d72c0'));
  fs.writeFileSync(path.join(DEST, 'logo-viola-negativo.svg'), svg('#fbf8f3', '#b9afe6'));
  const kb = (f) => (fs.statSync(path.join(DEST, f)).size / 1024).toFixed(1);
  console.log(`viewBox ${x0} ${y0} ${x1 - x0} ${y1 - y0} · colore viola campionato ${info.viola} · ${kb('logo-viola.svg')} KB`);
})();
