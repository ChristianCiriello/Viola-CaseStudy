// Schermate e controlli di impaginazione con Chrome headless.
//
//   node tools/schermate.mjs [base] [cartella] [pagine...] [--larghezze=375,1440] [--intera] [--ridotto]
//   es. node tools/schermate.mjs http://127.0.0.1:8880 anteprime / /check-up/ --larghezze=320,375,768,1440
//
// Per ogni pagina e larghezza: schermata del primo schermo (e della pagina intera con --intera),
// più i controlli: scroll orizzontale, elementi che escono dallo schermo, errori in console,
// immagini rotte, target tattili sotto i 44px su mobile.
import fs from 'node:fs';
import path from 'node:path';
import { avviaChrome, attendi } from './cdp.mjs';

const arg = process.argv.slice(2);
const opz = Object.fromEntries(arg.filter((a) => a.startsWith('--')).map((a) => { const [k, v] = a.slice(2).split('='); return [k, v ?? true]; }));
const pos = arg.filter((a) => !a.startsWith('--'));
const base = pos[0] || 'http://127.0.0.1:8890';
const dir = path.resolve(pos[1] || 'anteprime');
const pagine = pos.slice(2).length ? pos.slice(2) : ['/'];
const larghezze = (opz.larghezze || '375,1440').split(',').map(Number);
fs.mkdirSync(dir, { recursive: true });

const ALTEZZE = { 320: 568, 360: 740, 375: 667, 390: 844, 414: 896, 768: 1024, 1024: 768, 1280: 800, 1440: 900 };
const chrome = await avviaChrome({ webgl: false });
const esito = [];
try {
  for (const pagina of pagine) {
    for (const w of larghezze) {
      const h = ALTEZZE[w] || 900;
      const p = await chrome.nuovaPagina();
      await p.viewport(w, h, { mobile: w < 768, scala: w < 768 ? 2 : 1 });
      if (opz.ridotto) await p.invia('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'reduce' }] });
      await p.vai(base + pagina);
      await p.js('document.fonts.ready.then(() => true)');
      await attendi(opz.attesa ? Number(opz.attesa) : 2600);
      const nome = `${(pagina.replace(/\/$/, '').replace(/^\//, '') || 'home').replace(/\//g, '_')}-${w}`;
      await p.schermata(path.join(dir, `${nome}.jpg`));
      const controlli = await p.js(`(() => {
        const W = document.documentElement.clientWidth;
        const fuori = [...document.querySelectorAll('body *')].filter((el) => {
          const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
          if (!r.width || s.position === 'fixed' || el.closest('dialog:not([open]), [hidden], .nastro, .confetti, .nastro-scorre, .eroe__sfondo, .vetrina__arco-dietro, .vetrina__filo, .cartellino, .occasioni__lista, .recensioni__lista, .filtri, .chiusura__nastro, .chi-siamo__foto')) return false;
          return r.right > W + 1 || r.left < -1;
        }).slice(0, 8).map((el) => el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\\s+/).join('.') : '') + ' [' + Math.round(el.getBoundingClientRect().left) + '→' + Math.round(el.getBoundingClientRect().right) + ']');
        const piccoli = ${w < 768} ? [...document.querySelectorAll('a[href], button, input, summary')].filter((el) => {
          const r = el.getBoundingClientRect(); if (!r.width || el.closest('dialog:not([open]), [hidden], p, .piede, .vh, .salta')) return false;
          return r.height < 44 || r.width < 44;
        }).slice(0, 8).map((el) => el.tagName.toLowerCase() + ' «' + (el.textContent || el.getAttribute('aria-label') || '').trim().slice(0, 30) + '» ' + Math.round(el.getBoundingClientRect().width) + '×' + Math.round(el.getBoundingClientRect().height)) : [];
        const rotte = [...document.images].filter((i) => i.getAttribute('src') && i.complete && !i.naturalWidth && i.loading !== 'lazy').map((i) => i.currentSrc || i.src);
        return { scrollOrizzontale: document.documentElement.scrollWidth > W, larghezzaDoc: document.documentElement.scrollWidth, fuori, piccoli, rotte, altezza: document.documentElement.scrollHeight };
      })()`);
      if (opz.intera) await p.schermata(path.join(dir, `${nome}-intera.jpg`), { paginaIntera: true, qualita: 70 });
      if (opz.segmenti) {
        // schermate «a pezzi» scorrendo la pagina: le animazioni allo scroll partono come per un utente vero
        const passo = Math.round(h * 0.9);
        for (let y = h, i = 1; y < controlli.altezza && i <= Number(opz.segmenti); y += passo, i++) {
          await p.js(`window.scrollTo(0, ${y})`);
          await attendi(1100);
          await p.schermata(path.join(dir, `${nome}-s${String(i).padStart(2, '0')}.jpg`), { qualita: 72 });
        }
      }
      const errori = p.console.filter((c) => ['error', 'eccezione'].includes(c.tipo)).map((c) => c.testo);
      esito.push({ pagina, w, ...controlli, errori });
      p.chiudi();
    }
  }
} finally {
  await chrome.chiudi();
}
for (const e of esito) {
  const problemi = [e.scrollOrizzontale && `scroll orizzontale (${e.larghezzaDoc}px)`, e.fuori.length && `fuori schermo: ${e.fuori.join(', ')}`, e.piccoli.length && `target piccoli: ${e.piccoli.join(', ')}`, e.rotte.length && `immagini rotte: ${e.rotte.join(', ')}`, e.errori.length && `console: ${e.errori.join(' | ')}`].filter(Boolean);
  console.log(`${problemi.length ? '✗' : '✓'} ${e.pagina} @${e.w}  h=${e.altezza}${problemi.length ? '\n   ' + problemi.join('\n   ') : ''}`);
}
process.exit(0);
