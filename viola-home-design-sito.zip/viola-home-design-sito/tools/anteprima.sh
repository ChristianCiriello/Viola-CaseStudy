#!/bin/sh
# Build + copia nella cartella servita dall'anteprima (il pannello di anteprima non legge iCloud).
#   ./tools/anteprima.sh            poi config «viola-sito» in .claude/launch.json (porta 8890)
set -e
cd "$(dirname "$0")/.."
node tools/build.mjs
A="${ANTEPRIMA:-/private/tmp/claude-502/-Users-christianciriello-Library-Mobile-Documents-com-apple-CloudDocs-Claude-Code/92df8dc3-c3c0-4c78-93b1-979b053f9cb6/scratchpad/anteprima}"
mkdir -p "$A"
rsync -a --delete sito/ "$A/sito/"
cp tools/server.mjs "$A/server.mjs"
echo "→ anteprima aggiornata in $A"
