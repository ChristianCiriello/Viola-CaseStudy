// Disegna la mappa statica (MapLibre + tessere OpenFreeMap, © OpenStreetMap) con i colori del sito
// e la salva in WebP e AVIF. Sul sito resta un'immagine locale: nessuna richiesta a terzi.
//
//   node tools/mappa-statica.mjs   → src/assets/img/mappa-{800,1600}.{webp,avif}
//
// Usa la libreria MapLibre e lo stile già presenti nel progetto Studio Russo (stessa cartella iCloud).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { avviaChrome, attendi } from './cdp.mjs';

const qui = path.dirname(fileURLToPath(import.meta.url));
const destinazione = path.resolve(qui, '..', 'src', 'assets', 'img');
const russo = path.resolve(qui, '..', '..', 'studio-dentistico-russo-sito', 'sito', 'assets');
const vendor = path.join(russo, 'vendor', 'maplibre-gl');
const stile = JSON.parse(fs.readFileSync(path.join(russo, 'mappa', 'stile.json'), 'utf8'));

// Ricolorazione: dai toni caldi dello studio Russo ad avorio e lilla di Viola Home Design
const COLORI = {
  '#f5f2ec': '#f7f3ee', '#e1ebd9': '#e4ebdc', '#cddff2': '#d8dcf1', '#efebe3': '#efe9e2', '#d9e6d1': '#dce6d4',
  '#b7cfe9': '#bfc4ea', '#e7e1d6': '#e7e0d6', '#e9e4da': '#ebe5dc', '#fbfaf7': '#ffffff', '#d5dbe5': '#d9d4e6',
  '#e5b98f': '#b9afe6', '#f7dcc0': '#ece8f8', 'rgba(229,185,143,0.5)': 'rgba(185,175,230,0.55)', '#c7cdd8': '#cfc9de',
};
const ricolora = (v) => (typeof v === 'string' ? COLORI[v.toLowerCase()] || v : Array.isArray(v) ? v.map(ricolora) : v);
for (const l of stile.layers) for (const k of Object.keys(l.paint || {})) l.paint[k] = ricolora(l.paint[k]);
stile.name = 'Viola Home Design';

// Via Nazionale Appia, Casagiove (coordinate della scheda Google Maps)
const CENTRO = [14.3024223, 41.0734867];
const LARGHEZZA = 800, ALTEZZA = 560;

const pagina = `<!doctype html><meta charset="utf-8">
<link rel="stylesheet" href="/vendor/maplibre-gl.css">
<style>html,body{margin:0}#m{width:${LARGHEZZA}px;height:${ALTEZZA}px}.maplibregl-ctrl-attrib,.maplibregl-ctrl-logo{display:none!important}</style>
<div id="m"></div>
<script type="module">
  import * as maplibregl from '/vendor/maplibre-gl.mjs';
  const map = new maplibregl.Map({ container: 'm', style: '/stile.json', center: ${JSON.stringify(CENTRO)}, zoom: 15.6, interactive: false, attributionControl: false, fadeDuration: 0 });
  map.on('idle', () => { document.body.dataset.pronta = '1'; });
</script>`;

const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  if (url === '/') { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(pagina); }
  if (url === '/stile.json') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify(stile)); }
  if (url.startsWith('/vendor/')) {
    const f = path.join(vendor, path.basename(url));
    if (fs.existsSync(f)) { res.writeHead(200, { 'content-type': f.endsWith('.css') ? 'text/css' : 'text/javascript' }); return res.end(fs.readFileSync(f)); }
  }
  res.writeHead(404); res.end();
});
await new Promise((ok) => server.listen(0, '127.0.0.1', ok));
const origine = `http://127.0.0.1:${server.address().port}`;

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'viola-mappa-'));
const png = path.join(tmp, 'mappa.png');
const chrome = await avviaChrome();
try {
  const p = await chrome.nuovaPagina();
  await p.viewport(LARGHEZZA, ALTEZZA, { scala: 2 });
  await p.vai(`${origine}/`);
  try { await p.aspetta('document.body.dataset.pronta === "1"', { timeout: 90000 }); } catch (e) { console.error(p.console); throw e; }
  await attendi(1500);
  await p.schermata(png, { tipo: 'png', clip: { x: 0, y: 0, width: LARGHEZZA, height: ALTEZZA, scale: 2 } });
} finally {
  await chrome.chiudi();
  server.close();
}
fs.mkdirSync(destinazione, { recursive: true });
execFileSync('/usr/bin/python3', ['-c', `
import sys; sys.path.append('/Users/christianciriello/Library/Python/3.9/lib/python/site-packages')
from PIL import Image
im = Image.open(${JSON.stringify(png)}).convert('RGB')
for w in (800, 1600):
    r = im.resize((w, round(w * ${ALTEZZA} / ${LARGHEZZA})), Image.LANCZOS)
    r.save(${JSON.stringify(destinazione)} + f'/mappa-{w}.webp', 'WEBP', quality=80, method=6)
    r.save(${JSON.stringify(destinazione)} + f'/mappa-{w}.avif', 'AVIF', quality=60)
`]);
fs.rmSync(tmp, { recursive: true, force: true });
for (const f of fs.readdirSync(destinazione).filter((f) => f.startsWith('mappa-'))) console.log('✓', f, `${Math.round(fs.statSync(path.join(destinazione, f)).size / 1024)} KB`);
process.exit(0);
