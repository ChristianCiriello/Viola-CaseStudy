// Server statico di prova che si comporta come l'hosting: compressione gzip, intestazioni di cache
// e sicurezza (CSP letta da sito/.htaccess), pagina 404 e il redirect /recensione.
//
//   node tools/server.mjs [cartella] [porta]     es. node tools/server.mjs sito 8890
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const radice = path.resolve(process.argv[2] || 'sito');
const porta = Number(process.argv[3] || process.env.PORT || 8890);
const TIPI = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.webp': 'image/webp', '.avif': 'image/avif', '.jpg': 'image/jpeg', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml', '.webmanifest': 'application/manifest+json' };
const COMPRIMIBILI = /\.(html|css|js|json|svg|txt|xml|webmanifest)$/;
const leggiHtaccess = () => { try { return fs.readFileSync(path.join(radice, '.htaccess'), 'utf8'); } catch { return ''; } };

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  let p = decodeURIComponent(u.pathname);
  const htaccess = leggiHtaccess();
  const recensione = htaccess.match(/RewriteRule \^recensione\/\?\$ (\S+) \[R=302/)?.[1];
  if (recensione && /^\/recensione\/?$/.test(p)) { res.writeHead(302, { location: recensione }); return res.end(); }
  if (/(^|\/)\.(?!well-known\/)/.test(p)) { res.writeHead(403); return res.end('Forbidden'); }
  let f = path.join(radice, p);
  if (!f.startsWith(radice)) { res.writeHead(403); return res.end(); }
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) {
    if (!p.endsWith('/')) { res.writeHead(301, { location: p + '/' }); return res.end(); }
    f = path.join(f, 'index.html');
  }
  let stato = 200;
  if (!fs.existsSync(f)) { f = path.join(radice, '404.html'); stato = 404; if (!fs.existsSync(f)) { res.writeHead(404); return res.end('404'); } }
  const ext = path.extname(f);
  const csp = htaccess.match(/Content-Security-Policy "([^"]+)"/)?.[1];
  const intestazioni = {
    'content-type': TIPI[ext] || 'application/octet-stream',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'strict-origin-when-cross-origin',
    ...(csp && ext === '.html' ? { 'content-security-policy': csp.replace(' upgrade-insecure-requests', '') } : {}),
  };
  let corpo = fs.readFileSync(f);
  if (COMPRIMIBILI.test(f) && /gzip/.test(req.headers['accept-encoding'] || '')) { corpo = zlib.gzipSync(corpo, { level: 9 }); intestazioni['content-encoding'] = 'gzip'; intestazioni.vary = 'Accept-Encoding'; }
  res.writeHead(stato, intestazioni);
  res.end(corpo);
}).listen(porta, '127.0.0.1', () => console.log(`Anteprima con gzip e CSP su http://127.0.0.1:${porta}`));
