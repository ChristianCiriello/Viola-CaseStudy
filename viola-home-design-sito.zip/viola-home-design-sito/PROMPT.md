# PROMPT — Sito Viola Home Design (Casagiove, CE)

> Prompt di lavoro preparato il 12/10/2026. I dati vengono da Google Maps, Facebook, Instagram e Matrimonio.com.
> Va eseguito per fasi (§17). Non bisogna inventare nulla: ogni dato che manca diventa `[DA CONFERMARE]` nel codice e finisce nella lista del README.

---

## 1. Ruolo e obiettivo

Sei un senior web designer e front-end developer specializzato in siti per boutique e negozi locali. Lavori per Christian Ciriello (studio digitale, Caserta). Scrivi in italiano e commenti il codice in italiano.

Devi creare da zero il sito di **Viola Home Design**, negozio di bomboniere, liste nozze, articoli da regalo e casalinghi a Casagiove. Oggi il negozio non ha un sito. Il sito deve essere:

- **d'impatto**: una hero memorabile, con un'identità da boutique e non da template e-commerce;
- **mobile-first vero**: chi arriva da Instagram, Facebook e Google Maps deve poter fare tutto col pollice;
- **interattivo dove serve**: un configuratore di bomboniere, gallerie, stato "aperto ora" e recensioni navigabili;
- **con le recensioni in primo piano**: il 5,0 su Google è il vantaggio competitivo principale nella zona;
- **veloce e sicuro**: statico, senza database né login, con header di sicurezza e Lighthouse mobile ≥ 95;
- **in regola con privacy, cookie e GDPR**: informative complete, gestione del consenso integrata, mappe e contenuti di terzi bloccati fino al consenso.

Le conversioni da ottenere, in ordine:
1. **messaggio WhatsApp** con richiesta precompilata (dal configuratore o da un prodotto);
2. **visita in negozio** (indicazioni stradali);
3. **chiamata**;
4. appuntamento per la **lista nozze**.

**Niente e-commerce, carrello o area clienti.** Il negozio vende di persona e su consulenza: il sito deve portare le persone a contattare il negozio o a entrarci.

---

## 2. Dati reali (fonti pubbliche, rilevati il 12/10/2026)

| Dato | Valore | Fonte | Note |
|---|---|---|---|
| Nome | **Viola Home Design** (logo "Viola · Home Design") | logo, IG | Su Google il nome è "Viola Home Design - Bomboniere , Liste Nozze e Articoli Da regalo": è keyword stuffing e va corretto (§13) |
| Categoria | Negozio di bomboniere, lista nozze, articoli da regalo e casalinghi | bio IG | Google: "Negozio di souvenir di matrimonio". Facebook: "Gift Shop" |
| Indirizzo | Via Nazionale Appia, **298 o 300**, 81022 Casagiove (CE) | Google: 298. Facebook e Matrimonio.com: 300 | `[DA CONFERMARE]` il civico, poi va reso uguale ovunque |
| Plus code | 38F2+9X Casagiove (≈ 41.0760, 14.3030) | Google | Da verificare su Maps prima di scriverlo nel JSON-LD |
| Posizione | "all'uscita dell'autostrada Caserta Nord" | recensione Google | È un vantaggio da usare: si raggiunge facilmente da tutta la provincia |
| Telefono | 334 981 8211 | Google, Facebook | Cellulare. `[DA CONFERMARE]` se è anche WhatsApp (Business?) |
| Email | v.bomboniere@gmail.com | Facebook | Dopo la registrazione del dominio, proporre info@violahomedesign.it |
| Orari | Lun–sab 9:00–13:00 e 16:00–20:00 | Matrimonio.com | Google riporta "Apre alle ore 16:30" (rilevato lunedì 12/10). `[DA CONFERMARE]` l'apertura del pomeriggio (16:00 o 16:30) e se il lunedì mattina è chiuso |
| Servizi Google | Consegna a domicilio · "di proprietà di donne" | Google | Zone e costi della consegna `[DA CONFERMARE]` |
| Titolare | **Giampiera** ("Piera") | recensioni Matrimonio.com | Il cognome e il consenso a nominarla sono `[DA CONFERMARE]`. Le recensioni parlano di "la proprietaria" |
| Sito | violahomedesign.it, **indicato su Facebook ma il dominio risulta LIBERO** (whois .it: AVAILABLE) | whois 12/10/2026 | **Da registrare subito a nome del cliente** (§13) |
| Instagram | @violahomedesign · 426 follower | IG | Bio: "negozio di bomboniere, lista nozze, articoli da regalo e casalinghi" |
| Facebook | facebook.com/p/ViolaHomeDesign-100064036270632 · 3,4K follower | FB | Intro: "Le migliori proposte per eventi e per decorare la vostra casa". La pagina mostra "Opening Soon" e "Not yet rated": sono impostazioni sbagliate (§13). Ultimo post: "Rendi speciale il tuo compleanno" |
| Matrimonio.com | viola-home-design--e323724 · 5,0 (2 recensioni) · "da 3 €" · preventivo gratuito | Matrimonio.com | |
| Ragione sociale, P.IVA, PEC | — | — | `[DA CONFERMARE]`: obbligatori nel footer e nelle informative |

### Recensioni

| Fonte | Valutazione | Note |
|---|---|---|
| **Google** | **5,0 su 10 recensioni**, tutte a 5 stelle | Testi visibili: Mario Sterle (~mag 2026), Leonardo Vigorito (~gen 2026, con **risposta della titolare**), Stefania De Cristofaro (~gen 2026). Gli altri 7 testi e le versioni complete dei primi due vanno raccolti in Fase 0 (§17) |
| **Matrimonio.com** | 5,0 su 2 recensioni | Mariasilvia (27/01/2023, "Super consigliato!!!!"), Giusy (26/01/2023, "La scelta migliore") |

I temi che ricorrono nelle recensioni sono il materiale per scrivere il copy:
- la **consulenza della titolare** ("mi ha dato ottimi suggerimenti", "ci ha guidato nella scelta");
- **la qualità e la raffinatezza** ("prodotti raffinati", "articoli bellissimi, raffinati ed eleganti");
- **l'ampia scelta** ("negozio fornitissimo", "molto fornito");
- **tutti i budget** ("articoli per tutti i budget");
- **l'effetto "wow"** di regali e candele (regali di Natale);
- **la posizione** vicino all'uscita Caserta Nord.

### Prodotti e servizi (Matrimonio.com, Instagram, Facebook)

- **Bomboniere**: ballerine, bottigliette in miniatura, candele, bomboniere enogastronomiche (es. bottigliette d'olio), ceramiche, piante (piantine, bonsai, alberelli), profumatori, sculture, porcellane e **Capodimonte**, lanterne, corni portafortuna, scatole, portagioie, portacandela, coppie decorative, sacchettini per confetti.
- **Living Home**: quadri, lampade, vasi. **Tavola**: piatti, posate. Su entrambe le linee si può fare la **lista nozze**.
- **Servizi**: partecipazioni, segnaposto, confezioni personalizzate, catalogo, personalizzazione delle bomboniere.
- **Condizioni** (FAQ di Matrimonio.com):
  - ordinare **almeno 1 mese prima** dell'evento;
  - consegna di solito **una settimana prima**;
  - **nessun ordine minimo** e nessun sovrapprezzo per piccole quantità;
  - **spedizioni in tutta Italia** con un sovrapprezzo che dipende dall'ordine;
  - nessun limite particolare sui pagamenti.
- **Occasioni**: solo **matrimonio** e **compleanno** sono confermati da fonti (Matrimonio.com e post FB). I post con confezioni rosa e ciondolo a croce fanno pensare a **battesimo e comunione**. Battesimo, nascita, comunione, cresima, laurea e anniversari sono quindi `[DA CONFERMARE]` uno per uno.
- **Marchi trattati**: nessuna fonte li cita. Non nominarne nessuno finché il cliente non li conferma.

### Concorrenza (Google, ricerche correlate)

| Negozio | Valutazione |
|---|---|
| Il Particolare | 4,7 (26) |
| Il Sogno – Bomboniere, Eventi, Wedding Planner | 4,7 (11) |
| Viart Casanova | 4,5 (22) |
| Les Dames Bomboniere e Oggettistica | 4,5 (47) |

Viola ha meno recensioni ma è l'unico con 5,0 tra quelli mostrati. Sul sito si può scrivere "5,0 su Google". Non si può scrivere "il migliore" o "l'unico", perché non è verificabile.

### Identità visiva esistente

- **Logo**: "Viola" in corsivo calligrafico nero (copperplate) e "Home Design" in corsivo piccolo. Sopra c'è un fregio floreale nero con un fiore viola/lilla, in alto una **fascia curva lilla** ("swoosh"), su fondo bianco. Nelle foto pubblicate è presente anche come watermark.
- **Foto del negozio**: ambienti bianchi e luminosi, ceramiche opache bianche, sabbia e grigie (gufi, elefanti, tartarughe), rose rosa, confezioni con nastri di raso, fiori di stoffa e cesti in vimini.
- Le foto sono pubblicate su FB e IG **con il watermark** e in risoluzione social. Per il sito servono gli originali (§11).

---

## 3. Vincoli non negoziabili

1. **Nessun dato inventato**: prezzi, marchi, occasioni, orari, nomi, zone di consegna e tempi solo da fonte, altrimenti `[DA CONFERMARE]`. L'unico prezzo documentato è "bomboniere **da 3 €**".
2. **Recensioni riportate alla lettera**: niente tagli che cambiano il senso e niente recensioni inventate o "migliorate". Ogni recensione indica fonte, mese e anno. Il nome si mostra come **nome + iniziale del cognome**. Va inserita la **nota di trasparenza** richiesta dal Codice del Consumo (art. 22 c. 4-bis, D.Lgs. 26/2023 "Omnibus"), che spiega da dove vengono le recensioni e se sono verificate (§9).
3. **Niente `aggregateRating` né `Review` nel JSON-LD**: per un'attività che parla di sé sono recensioni autoreferenziali, che Google ignora o penalizza. Le recensioni si mostrano solo a video.
4. **Nessun contenuto di terzi caricato prima del consenso**: niente iframe di Google Maps, embed di Instagram, font Google o pixel. Font e script sono tutti self-hosted.
5. **Nessun form che invia dati al server**: il configuratore compone un messaggio che l'utente invia da solo via WhatsApp o email. Così non c'è nessun trattamento lato server, e anche nessuna superficie d'attacco o spam.
6. **Accessibilità WCAG 2.2 AA**:
   - testo base di 17–18px;
   - il lilla del logo **non si usa per il testo** su chiaro (§10);
   - target tattili di almeno 48px;
   - `prefers-reduced-motion` rispettato;
   - sito completo e navigabile anche senza JavaScript (il configuratore senza JS diventa un elenco di link WhatsApp per occasione).
7. **Niente foto stock che sembrano prodotti del negozio**: chi le vede penserebbe che siano articoli in vendita. Vanno bene solo foto reali del cliente. In attesa delle foto, si usano composizioni grafiche (nastro, confetti, texture carta e raso).

---

## 4. Pubblico e intenti

| Chi | Cosa cerca | Azione principale |
|---|---|---|
| Coppia che si sposa | Bomboniere, confezioni, segnaposto, partecipazioni, lista nozze | Configuratore → WhatsApp / appuntamento |
| Genitori (battesimo, comunione, cresima) `[DA CONFERMARE]` | Bomboniere a tema, tempi e budget | Configuratore → WhatsApp |
| Laureandi, chi festeggia un compleanno | Bomboniere e regali per la festa | WhatsApp |
| Chi cerca un regalo (Natale, casa nuova, ricorrenze) | Idee regalo, candele, porcellane, Capodimonte | Indicazioni / WhatsApp |
| Invitati a un matrimonio | Lista nozze degli sposi | Chiama / WhatsApp |
| Chi è fuori zona | Spedizione in Italia | WhatsApp / email |

**Tono di voce**: caldo, elegante e concreto, mai sdolcinato.
- Si usa il **"tu"** nelle parti generali e il **"voi"** nelle pagine per gli sposi e la lista nozze, come fa già il negozio su Matrimonio.com.
- Frasi brevi. Si parla di dettagli veri (nastri, confezioni, consulenza), non di aggettivi.

---

## 5. Architettura del sito (multi-pagina, per la SEO)

```
/                                   Home
/bomboniere/                        Hub: occasioni, stili, come si ordina, tempi
  /bomboniere/matrimonio/           (confermata)
  /bomboniere/battesimo-nascita/    [DA CONFERMARE] pubblicata solo se il cliente la conferma
  /bomboniere/comunione-cresima/    [DA CONFERMARE]
  /bomboniere/laurea/               [DA CONFERMARE]
  /bomboniere/compleanno-anniversario/  (compleanno confermato da FB)
/lista-nozze/                       Come funziona, Tavola e Living, appuntamento
/casa-e-regali/                     Idee regalo, candele, porcellane, Capodimonte, casalinghi
/recensioni/                        Tutte le recensioni, riepilogo, nota di trasparenza, "lascia una recensione"
/chi-siamo/                         La titolare, il negozio, il metodo (consulenza)
/contatti/                          Orari, mappa (con consenso), come arrivare da A1 Caserta Nord
/domande-frequenti/
/privacy-policy/  /cookie-policy/  /note-legali/  /404
/recensione                         redirect 302 al link "scrivi una recensione" di Google (per il QR in negozio)
```

- Le pagine di occasione dipendono da un flag `pubblica: true/false` in `data/occasioni.json`. Il build genera solo quelle attive e aggiorna di conseguenza menu, sitemap e configuratore.
- **Navigazione principale** (5 voci al massimo): **Bomboniere · Lista nozze · Casa e regali · Recensioni · Contatti**. Chi siamo e FAQ vanno nel footer e nei link contestuali.

---

## 6. HERO: la parte che deve colpire

**Concept: "Il nastro viola".** La fascia lilla del logo diventa un **nastro di raso** che attraversa lo schermo, avvolge la vetrina e si chiude in un **fiocco**. Ogni bomboniera finisce con un fiocco: il sito "confeziona" il primo schermo come si confeziona un regalo. Il nastro torna poi in tutto il sito come motivo grafico (divisori, card, stati attivi).

### Desktop (≥1024px)

- **Fondo**: hero a tutto schermo (`min-height: 100svh`, max ~900px) su `--avorio`, con una texture carta finissima (SVG noise sotto 1 KB) e un alone lilla radiale molto morbido.
- **A destra, la "vetrina ad arco"**: una cornice ad arco (come una finestra di vetrina) con le **foto reali** del negozio.
  - Le foto sono 4, una per occasione o linea.
  - Crossfade ogni 5 secondi con un lieve Ken Burns (scala da 1,06 a 1).
  - Un'etichetta cambia insieme alla foto: "Matrimonio" · "Battesimo" · "Casa" · "Regali".
  - Dietro l'arco c'è una seconda cornice sfalsata in `--glicine`, per dare profondità.
- **Il nastro**: è un path SVG lilla con riflesso di raso (gradiente lineare a 3 stop).
  - Entra dal bordo sinistro, passa dietro il titolo, avvolge l'arco e si chiude in un fiocco in alto a destra dell'arco.
  - Animazione d'ingresso: `stroke-dashoffset` in 1,4s. Il fiocco compare con una scala elastica a 1,1s.
  - Allo scroll i lembi del nastro scorrono leggermente e il fiocco ruota di pochi gradi. Si usano **solo transform e opacity**.
- **Confetti**: 5–7 confetti (mandorle di zucchero) in SVG, nei colori cipria, avorio, lilla e salvia chiaro.
  - Fluttuano lentamente, con parallax legato al puntatore su desktop.
  - Si fermano quando la hero non è visibile.
  - Riprendono il tema della bomboniera senza la banalità dei coriandoli.
- **A sinistra**:
  - **Chip di stato in tempo reale**: "● Aperto ora · chiude alle 20:00" oppure "Chiuso · riapre oggi alle 16:00". È calcolato da `data/orari.json` con timezone Europe/Rome e tiene conto degli avvisi. **Si mostra solo quando gli orari sono confermati.**
  - **H1** grande in serif, con rivelazione riga per riga. Proposte:
    1. "Bomboniere e regali **che si ricordano**." ← consigliata
    2. "Il dettaglio che resta, **dopo la festa**."
    3. "Ogni festa merita il suo **fiocco**."

    La parola in grassetto va in corsivo serif colore `--viola-700`. L'H1 resta **statico** (niente parole che ruotano), perché conta per SEO e accessibilità.
  - **Sottotitolo**: "Bomboniere per ogni occasione, liste nozze e idee per la casa a Casagiove, all'uscita Caserta Nord. Ti aiutiamo a scegliere, per ogni budget."
  - **CTA**:
    - primaria "**Crea la tua bomboniera**", che porta al configuratore (§8);
    - secondaria "Scrivici su WhatsApp", con testo precompilato;
    - link testuale "Come arrivare →".
  - **Badge recensioni** subito sotto le CTA: ★★★★★ **5,0 su Google** · 10 recensioni, che porta a `/recensioni/`. Accanto, una mini-citazione a rotazione (2–3 estratti di massimo 12 parole, con nome e iniziale).
- **Sotto la piega**, un **nastro scorrevole** (marquee lento, che si ferma all'hover, statico con reduced-motion):
  - Matrimonio · Battesimo · Comunione · Laurea · Compleanno · Lista nozze · Idee regalo (solo le occasioni confermate);
  - alternato a "Bomboniere da 3 €" · "Spedizioni in tutta Italia" · "Consegna a domicilio".

### Mobile (<768px)

Al primo schermo (375×667) devono stare:
- l'**arco foto** in alto (al massimo 34svh), con il nastro che lo attraversa e il **badge "★ 5,0 Google" sovrapposto all'arco** (pillola in vetro smerigliato);
- il chip di stato;
- l'H1 su 3 righe al massimo;
- la CTA primaria a tutta larghezza.

Subito sotto vanno il sottotitolo breve, la CTA WhatsApp e il nastro scorrevole.

Riduzioni rispetto al desktop:
- 3 confetti al posto di 5–7;
- niente parallax del puntatore;
- foto dell'arco a 4:5;
- H1 con `clamp(2.4rem, 10vw, 3.4rem)` e interlinea 1.02.

### Upgrade previsto (dopo lo shooting, §11)

Un loop video di 6–8 secondi con **mani che chiudono un fiocco lilla** su una confezione sostituisce la foto nell'arco su desktop:
- MP4/WebM, muto, sotto 1,2 MB, con poster;
- non si carica con `Save-Data` né con reduced-motion.

### Performance e fallback

- **LCP**: su desktop è l'H1, su mobile probabilmente la prima foto dell'arco. Quella foto va in **AVIF/WebP con `srcset`**, `fetchpriority="high"` e preload, sotto i 60 KB a 390px.
- Le altre 3 foto si caricano dopo `load`.
- Nastro, fiocco e confetti sono SVG inline, sotto i 6 KB in tutto.
- Con `prefers-reduced-motion` il nastro è già disegnato, i confetti sono fermi e la foto è unica.
- Senza JS la hero è completa: prima foto, CTA funzionanti, nessun chip.
- Obiettivi:
  - LCP < 2,0 s su 4G simulato;
  - CLS < 0,05;
  - JS totale del sito < 35 KB gzip;
  - CSS < 40 KB gzip.

---

## 7. Home: sezioni in ordine

1. **Hero** (§6) con il nastro scorrevole.
2. **Barra avvisi** (se ci sono avvisi attivi).
   - Esempio: "Natale 2026: idee regalo e confezioni su misura" `[DA CONFERMARE date]`.
   - Legge `data/avvisi.json` con `{testo, link, dal, al}` e si nasconde da sola alla scadenza.
   - Alimenta anche `specialOpeningHoursSpecification` per le aperture straordinarie.
3. **Per ogni occasione**: card ad arco con foto reale, nome dell'occasione e link alla pagina.
   - Su mobile: carosello con scroll-snap e card all'82% della larghezza, così si intravede la successiva.
   - Su desktop: griglia.
   - Ogni card ha anche "Crea la bomboniera" che apre il configuratore con l'occasione già selezionata.
4. **Configuratore "Crea la tua bomboniera"** (§8): è la sezione interattiva principale.
5. **Recensioni** (§9): sezione grande e scura (`--inchiostro`) per stacco visivo.
   - Riepilogo 5,0 con barre di distribuzione e carosello di card-citazione.
   - Le risposte della titolare, quando ci sono, compaiono sotto la recensione.
   - CTA "Leggi tutte" e "Lascia la tua recensione".
6. **Lista nozze**:
   - blocco a due colonne con foto della tavola apparecchiata (Tavola: piatti, posate; Living: quadri, lampade, vasi);
   - 3 passi: "Fissate un appuntamento" → "Scegliete insieme a noi" → "I vostri invitati vi fanno il regalo" `[DA CONFERMARE modalità per gli invitati: in negozio, a distanza, bonifico?]`;
   - CTA "Prenota l'appuntamento per la lista".
7. **Casa e idee regalo**: galleria "vetrina" filtrabile (§10) per categoria.
   - Categorie: candele e profumatori, porcellane e Capodimonte, ceramiche, lanterne, corni portafortuna, portagioie e scatole.
   - Ogni oggetto ha il bottone "Chiedi info", che apre WhatsApp con nome e riferimento dell'oggetto.
8. **Perché da Viola**: 4–6 punti, tutti presi da fonti.
   - consulenza della titolare, per ogni budget;
   - confezioni personalizzate, segnaposto e partecipazioni;
   - nessun ordine minimo;
   - spedizioni in tutta Italia;
   - consegna a domicilio;
   - all'uscita A1 Caserta Nord.
9. **I tempi giusti**: mini-timeline orizzontale (scroll-snap su mobile).
   - Le tappe: "Almeno 1 mese prima: scegli e ordina" → "Confezionamento e personalizzazione" → "Circa 1 settimana prima: ritiro o consegna" → "Il giorno della festa".
   - Contiene un mini-calcolatore: "Quando ti sposi / quando è la festa?" con un campo data che risponde "Ordina entro il {data − 30 giorni}".
10. **Chi siamo** (estratto): la titolare `[DA CONFERMARE nome e foto]`, il negozio e il link alla pagina.
11. **FAQ**: 6 domande in accordion `<details>`, con FAQPage nel JSON-LD.
12. **Dove siamo**:
    - mappa con consenso (§12) e indirizzo;
    - orari di oggi in evidenza e tabella della settimana;
    - "Dall'uscita A1 Caserta Nord: X minuti" `[DA CONFERMARE]`;
    - parcheggio `[DA CONFERMARE]`;
    - bottoni Indicazioni (Google Maps / Apple Maps / Waze), Chiama e WhatsApp.
13. **Instagram**: griglia di 6 foto statiche **ospitate sul sito** (nessun embed), con link al profilo.
14. **CTA finale**: "Raccontaci la tua festa" con WhatsApp, Chiama e Vieni a trovarci.
15. **Footer**:
    - logo, intro, contatti, orari e social;
    - dati legali (ragione sociale e P.IVA);
    - link a Privacy, Cookie, Note legali e **Preferenze cookie**;
    - credito "Sito di Christian Ciriello".

---

## 8. Configuratore "Crea la tua bomboniera" (cuore interattivo)

Wizard a 4 passi, vanilla JS, accessibile da tastiera, con barra di avanzamento a forma di nastro che "si riempie".

1. **Occasione**: card con icona SVG per ogni occasione **attiva** in `data/occasioni.json`, più "Altro".
2. **Stile**: card con foto reale. Gli stili sono raggruppati dai prodotti documentati:
   - **Eleganza classica**: porcellane, Capodimonte, sculture, coppie decorative;
   - **Natura**: piantine, bonsai, alberelli;
   - **Luce e profumo**: candele, profumatori, lanterne, portacandela;
   - **Gusto**: bottigliette d'olio, bomboniere enogastronomiche;
   - **Portafortuna**: corni;
   - **Casa e design**: ceramiche, portagioie, scatole;
   - **"Consigliatemi voi"**.
3. **Budget per bomboniera**: fasce "da 3 a 5 €" · "5–10 €" · "10–20 €" · "oltre 20 €" · "Preferisco parlarne".
   - Le fasce sono `[DA CONFERMARE]` col cliente: l'unico dato documentato è "da 3 €".
   - Accanto c'è la nota "Ti aiutiamo a trovare la soluzione giusta per ogni budget", presa dalle recensioni.
4. **Dettagli**:
   - numero di pezzi (stepper con input numerico) e data dell'evento (input date);
   - extra a checkbox: confezione personalizzata, sacchettini per confetti, segnaposto, partecipazioni (servizi documentati);
   - nome, facoltativo.

**Risultato**:
- **Card riepilogo** stile "biglietto" con nastro e fiocco, che contiene:
  - occasione, stile, budget, pezzi, data ed extra;
  - **"Ordina entro il {data − 30 gg}"**. Se mancano meno di 30 giorni compare il messaggio "I tempi sono stretti: scrivici subito e vediamo insieme cosa si può fare", senza promettere nulla.
- **Bottoni**:
  - "**Invia su WhatsApp**" (`wa.me/393349818211?text=…` con riepilogo leggibile);
  - "Invia per email" (`mailto:` con oggetto e corpo);
  - "Preferisco venire in negozio", che apre WhatsApp con un messaggio di richiesta appuntamento.
- Sotto i bottoni, una micro-informativa: "Il messaggio parte dal tuo WhatsApp o dalla tua email: questo sito non salva i tuoi dati. [Privacy]".

**Comportamento**:
- Lo stato è salvato in `localStorage` (con try/catch) per chi torna sul sito. È una funzionalità richiesta dall'utente e quindi rientra tra quelle tecniche (va dichiarata nella cookie policy).
- C'è un bottone "Ricomincia".
- I parametri sono in URL (`?occasione=matrimonio&stile=natura`), così le card delle occasioni e i post social possono aprire il configuratore già impostato.

**Senza JS**: il configuratore diventa un elenco di link WhatsApp precompilati, uno per occasione.

---

## 9. Recensioni in evidenza

**Dati**: `data/recensioni.json`, con un oggetto per recensione:

```json
{ "fonte": "google|matrimonio", "autore": "Stefania D.", "data": "2026-01", "stelle": 5,
  "testo": "…testo integrale…", "estratto": "…max 12 parole…", "risposta_titolare": "…|null",
  "tema": ["consulenza","qualita","natale"] }
```

**Dove compaiono**:
- **Hero**: badge 5,0 e mini-citazioni a rotazione.
- **Home**: sezione scura con:
  - un riepilogo grande: "5,0" in serif enorme, 5 stelle disegnate, "10 recensioni su Google · 2 su Matrimonio.com";
  - le barre di distribuzione per stelle;
  - un carosello di card (scroll-snap, frecce su desktop, swipe su mobile).
- **Card**:
  - testo con "Leggi tutto" se supera 4 righe;
  - autore, mese e anno, logo della fonte e stelle;
  - la risposta della titolare, se presente, in una card annidata.
- **Citazioni contestuali**:
  - consulenza → configuratore;
  - Natale e candele → Casa e regali;
  - matrimonio → pagina matrimonio;
  - posizione → Dove siamo.
- **Pagina `/recensioni/`**:
  - tutte le recensioni, con filtro per fonte e per tema;
  - riepilogo e link "Leggi su Google" e "Leggi su Matrimonio.com";
  - CTA "**Lascia la tua recensione**", che porta a `/recensione`, cioè al redirect verso il link di scrittura di Google (Place ID `[DA RECUPERARE]`).

**Nota di trasparenza (obbligatoria)**, sotto ogni blocco recensioni e per intero nella pagina dedicata:

> "Le recensioni sono riportate testualmente da Google e Matrimonio.com, dove sono state pubblicate dai clienti. Non le modifichiamo e le riportiamo tutte, non solo una selezione. Le piattaforme di origine non verificano che l'autore abbia effettivamente acquistato." (Codice del Consumo, art. 22 c. 4-bis)

**Aggiornamento**: il README spiega come aggiungere una recensione a `recensioni.json` e rigenerare il sito. Il riepilogo numerico viene calcolato dal file, mai scritto a mano.

**Kit fuori dal sito** (da passare a Christian): un QR per il bancone e per i biglietti nelle confezioni, che punta a `violahomedesign.it/recensione`.

---

## 10. Design system

**Direzione: "Atelier del regalo".** È una boutique luminosa ed editoriale. Matericità di **raso, carta e ceramica opaca**, archi da vetrina, nastro come segno, molto bianco caldo. Elegante ma accogliente, mai pacchiano: niente glitter, cuori o font corsivi nei testi.

**Palette** (derivata dal logo e dalle foto del negozio, con contrasti da verificare in build):

| Token | Valore | Uso |
|---|---|---|
| `--inchiostro` | `#1E1A26` | testi, sezione recensioni, footer (nero con sottotono viola, come il corsivo del logo) |
| `--viola-700` | `#5B4A93` | link, parole in corsivo dell'H1, bottoni primari (≈ 7:1 su bianco, AA) |
| `--lilla` | `#A497D4` | colore del logo: nastro, fiocco, superfici e decori. **Mai per il testo su chiaro** (≈ 2,6:1) |
| `--glicine` | `#EEEAF7` | sezioni alternate, cornici secondarie |
| `--avorio` | `#FBF8F3` | sfondo |
| `--sabbia` | `#E9E1D6` | card, ceramiche, bordi caldi |
| `--cipria` | `#EBCFCB` | accenti (rose e nastri rosa delle foto), confetti |
| `--champagne` | `#C8B48C` | filetti sottili, ornamenti e stelle delle recensioni su fondo scuro |
| `--stato` | `#2E7D4F` | "Aperto ora" |
| `--wa` | `#25D366` con testo `--inchiostro` | bottoni WhatsApp |

**Tipografia** (self-hosted WOFF2, subset latino, `font-display: swap`, preload del solo display):
- **Display**: **Instrument Serif**, regular e *italic*, per H1/H2, numeri grandi (il "5,0") e citazioni. Il corsivo serif si usa per le parole-emozione.
- **Testo e UI**: **Hanken Grotesk** (variabile), 17–18px, interlinea 1.6.
- **Logo**: unico elemento in corsivo calligrafico, in SVG. **Nessun font script nei testi.**
- Scala fluida con `clamp()`, cifre tabellari per orari e date.

**Forme e componenti**:
- **Archi** (`border-radius: 999px 999px 24px 24px`) per foto e card delle occasioni.
- Raggi di 20–28px altrove, ombre morbide e calde.
- **Divisore a nastro**: linea SVG lilla sottile con un piccolo fiocco centrale, tra le sezioni chiave.
- **Bottoni**: a pillola. Il primario è `--viola-700` con un **riflesso di raso** che scorre all'hover/focus (gradiente in transform). Il secondario ha bordo `--inchiostro`.
- **Chip** per categorie e filtri, accordion nativi `<details>`.
- **Icone SVG originali** a tratto 1,5px: anelli, colomba o culla, calice, tocco, torta, casa, candela, fiocco, pacco, camion, mappa.

**Motion**:
- solo transform e opacity, durate di 200–700ms, easing `cubic-bezier(.2,.7,.2,1)`;
- reveal allo scroll con IntersectionObserver (una sola volta);
- il fiocco ha una piccola "molla" sugli stati attivi;
- tutto disattivato con `prefers-reduced-motion`.

**Galleria "vetrina"** (`data/vetrina.json`):
- ogni oggetto ha `{id, titolo, categoria, occasioni[], foto, alt, novita}`;
- filtri a chip e griglia masonry leggera (CSS columns);
- **lightbox** con swipe, tastiera e contatore;
- bottone "Chiedi info su WhatsApp" con riferimento all'oggetto;
- **niente prezzi**, a meno che il cliente non li fornisca.

**Logo**:
- ridisegno SVG fedele (corsivo "Viola", "Home Design", fregio con fiore, fascia lilla), da far approvare;
- se il cliente ha l'originale vettoriale (tipografia o insegna), si usa quello;
- servono anche: versione monocroma per il fondo scuro, `favicon.svg` (fiore del fregio), `apple-touch-icon` e icone del manifest.

---

## 11. Foto

- **Fase 1** (subito, **con l'OK del cliente**):
  - si usano le foto già pubblicate su FB/IG (prodotti, confezioni, interni);
  - vanno scaricate in `sorgenti/social/`, ritagliate ed esportate in AVIF/WebP con `srcset`;
  - nel README vanno segnate come "**da sostituire con gli originali senza watermark**".
- **Richiesta al cliente**: gli originali senza watermark (dal telefono o dal fotografo).
- **Shooting da proporre** (upsell, ~25 scatti):
  - facciata con insegna;
  - panoramica degli interni;
  - vetrina;
  - dettagli delle confezioni (nastri, fiori di stoffa, sacchettini);
  - tavola apparecchiata per la lista nozze;
  - candele accese;
  - Capodimonte e porcellane;
  - **mani che chiudono un fiocco lilla** (per il video della hero);
  - la titolare al bancone (se acconsente).
- **Formati**:
  - archi in 4:5;
  - gallery a formato libero;
  - OG in 1200×630 dedicata;
  - alt descrittivi in italiano per tutte le immagini.

---

## 12. Privacy, cookie e GDPR (tutto integrato)

**Principio**: privacy by default. All'apertura il sito **non installa cookie di profilazione** e non contatta domini terzi.

**Consent manager proprio** (`consenso.js`, nessuna CMP esterna), conforme alle **Linee guida del Garante del 10/06/2021**:
- **Categorie**:
  - **Necessari** (sempre attivi: cookie di consenso, stato del configuratore);
  - **Contenuti esterni** (Google Maps);
  - **Statistiche** (GA4 con Consent Mode v2);
  - **Marketing** (Meta Pixel).
- Le categorie Statistiche e Marketing esistono **solo se configurate** (`ga4_id` e `meta_pixel_id` in `src/config.json`).
- Al lancio sono vuote, quindi **il banner non compare da solo**. Diventa automatico appena si attiva GA4 o Pixel (utile per future campagne ADV).
- **Banner** (quando serve):
  - "Accetta tutto", "Rifiuta tutto" e "Personalizza" con **pari evidenza**;
  - la X chiude e vale come rifiuto;
  - nessuna casella pre-spuntata e nessuno scroll-to-consent;
  - link alla cookie policy.
- **Scelta**:
  - salvata per **6 mesi** in un cookie tecnico di prima parte (`vhd_consenso`, con versione della policy e data);
  - si ripropone se cambia la versione della policy o se scadono i 6 mesi;
  - si rivede in ogni momento da "**Preferenze cookie**" nel footer.
- **Google Maps**:
  - al posto dell'iframe c'è un segnaposto con mappa statica locale (immagine generata in build) e il testo "Per vedere la mappa interattiva Google carica i suoi cookie" + bottone "Carica la mappa";
  - il bottone registra il consenso alla categoria "Contenuti esterni" nello stesso store;
  - accanto ci sono sempre i link diretti a Google Maps, Apple Maps e Waze, che non richiedono consenso.
- **Instagram**: nessun embed, solo immagini locali con link.
- **WhatsApp ed email**: link che l'utente apre da sé. Vicino ai bottoni c'è una micro-informativa: aprendo WhatsApp, i dati vengono trattati da Meta come titolare autonomo.

**Pagine legali** (testi completi, scritti sui trattamenti **reali** del sito):

- **Privacy policy** (artt. 13–14 GDPR):
  - titolare `[ragione sociale, P.IVA, sede, email/PEC: DA CONFERMARE]`;
  - dati trattati: contatti spontanei via WhatsApp, email e telefono, log tecnici del server;
  - finalità e basi giuridiche: misure precontrattuali, art. 6.1.b; sicurezza, legittimo interesse, art. 6.1.f;
  - destinatari: provider di hosting; Meta e Google come titolari autonomi se l'utente sceglie i loro servizi;
  - trasferimenti extra-UE: Data Privacy Framework;
  - tempi di conservazione;
  - diritti degli artt. 15–22, reclamo al Garante;
  - assenza di processi decisionali automatizzati;
  - data di aggiornamento.
- **Cookie policy**:
  - tabella di cookie e storage (nome, finalità, durata, prima o terza parte, categoria);
  - le categorie opzionali compaiono solo se attive;
  - come revocare il consenso, link alle policy di Google e Meta.
- **Note legali**:
  - ragione sociale, sede, **P.IVA** (obbligatoria sul sito per art. 35 DPR 633/72), REA `[DA CONFERMARE]`;
  - proprietà dei contenuti e delle foto;
  - nota sui prezzi indicativi.
- **Footer**: P.IVA e link legali in ogni pagina.

---

## 13. SEO locale, GEO e AEO

- **Title e description** unici per pagina. Esempio per la home:
  - title: "Viola Home Design · Bomboniere, Lista Nozze e Regali a Casagiove (Caserta)";
  - description: "Bomboniere per matrimonio e ogni occasione, liste nozze e idee regalo all'uscita A1 Caserta Nord. 5,0 su Google. Consulenza per ogni budget. Tel. 334 981 8211."
- **Keyword target**:
  - bomboniere Caserta, bomboniere Casagiove, bomboniere matrimonio Caserta;
  - bomboniere comunione / battesimo / laurea Caserta (se confermate);
  - lista nozze Caserta, articoli da regalo Caserta, idee regalo Caserta;
  - porcellane Capodimonte Caserta, segnaposto e partecipazioni matrimonio Caserta;
  - sacchetti confetti personalizzati.
- **Comuni vicini** da citare con naturalezza, senza pagine doorway:
  - Caserta, San Nicola la Strada, Recale, Capodrise, Maddaloni, Marcianise;
  - San Prisco, Casapulla, Curti, Santa Maria Capua Vetere, Capua, San Leucio.
- **JSON-LD `@graph`**:
  - `Store` + `HomeGoodsStore`, con: name, url, logo, image, telephone, email, address (civico confermato), geo, `hasMap`;
  - `openingHoursSpecification`, `specialOpeningHoursSpecification` (da avvisi.json), `priceRange` ("Bomboniere da 3 €"), `areaServed`, `sameAs` (IG, FB, Matrimonio.com);
  - `hasOfferCatalog` con le categorie (bomboniere per occasione, lista nozze, casa e regali), `founder` solo se confermato;
  - `WebSite`, `BreadcrumbList` e `FAQPage` dove servono;
  - **niente `aggregateRating` né `Review`** (§3).
- **GEO/AEO**:
  - `/llms.txt` con i fatti chiave: indirizzo, telefono, orari, servizi, "bomboniere da 3 €", tempi d'ordine, spedizioni, link;
  - `robots.txt` che ammette GPTBot, ClaudeBot, PerplexityBot e Google-Extended;
  - un box "**In breve**" all'inizio di ogni pagina interna, con la risposta diretta in 2–4 righe;
  - FAQ con risposte di 1–2 frasi, dati NAP identici ovunque.
- **FAQ di partenza** (le risposte vengono da Matrimonio.com e vanno confermate):
  - Con quanto anticipo ordinare le bomboniere?
  - C'è un ordine minimo?
  - Spedite fuori Caserta?
  - Fate la consegna a domicilio?
  - Personalizzate confezioni e segnaposto?
  - Come funziona la lista nozze?
  - Quanto costa una bomboniera?
  - Dove siete e come si arriva?
- **Tecnica**:
  - `sitemap.xml` con lastmod e canonical;
  - Open Graph e Twitter card;
  - `site.webmanifest`, `lang="it"`;
  - una 404 utile (occasioni, configuratore, contatti).

**Fuori dal sito** (lista d'azione per Christian, nel README):
1. **Registrare subito `violahomedesign.it` a nome del cliente.** Il dominio è libero, è già linkato da Facebook e oggi chiunque potrebbe prenderlo.
2. Google Business Profile:
   - nome → "Viola Home Design" (il nome attuale con le keyword viola le linee guida e rischia la sospensione);
   - civico unico;
   - orari corretti;
   - link al sito;
   - categorie secondarie (negozio di articoli da regalo, negozio di casalinghi).
3. Facebook: togliere "Opening Soon", attivare le recensioni, aggiornare il sito.
4. Instagram: link al sito in bio, con UTM.
5. Matrimonio.com: orari e link al sito allineati.
6. QR "Lascia una recensione" in negozio (§9).

---

## 14. Mobile: requisiti precisi

- **Barra azioni fissa in basso** (solo sotto i 768px), che compare dopo la hero: [WhatsApp] [📞 Chiama] [📍 Arriva].
  - Alta 64px più `env(safe-area-inset-bottom)`.
  - Si nasconde quando è visibile il footer o il riepilogo del configuratore.
  - Non copre mai le CTA della pagina.
- **Header** compatto da 60px:
  - contiene il logo, l'icona WhatsApp sempre visibile e l'hamburger;
  - l'hamburger apre un **foglio a tutto schermo** con voci grandi (24px), orari di oggi, i 3 bottoni d'azione e un piccolo nastro decorativo;
  - il foglio si chiude con Esc o con lo swipe, e tiene il focus intrappolato;
  - l'header si nasconde scorrendo verso il basso e ricompare scorrendo verso l'alto.
- **Link**: tutti i numeri sono `tel:`, l'indirizzo apre Maps e WhatsApp usa `wa.me` con testo precompilato per ogni contesto (occasione, oggetto, lista nozze, appuntamento).
- **Interazioni**:
  - niente che funzioni solo con l'hover;
  - caroselli con scroll-snap nativo e indicatori;
  - la card successiva si vede sempre in parte;
  - il wizard del configuratore occupa tutta la larghezza e ha i bottoni Avanti/Indietro in fondo, raggiungibili col pollice.
- **Layout**:
  - zero scroll orizzontale da 320px in su;
  - gutter di 16–20px;
  - tabella degli orari trasformata in lista;
  - testo di almeno 16px (17–18px per il corpo) e target di almeno 48×48px.
- **Test** a 320, 360, 375, 390, 414, 768, 1024 e 1440px, in verticale e in orizzontale.

---

## 15. Tecnica e sicurezza

- **Stack**:
  - HTML/CSS/JS vanilla statico, senza framework, generato da `tools/build.mjs` (Node, nessuna dipendenza a runtime);
  - il build compone i partial (head, header, footer, JSON-LD, barra mobile) da `src/` in `sito/`;
  - genera pagine di occasione, sitemap, llms.txt, mappa statica e hash CSP;
  - le immagini passano da `tools/immagini.mjs` (sharp installato **fuori da iCloud**) e diventano AVIF/WebP con `srcset`.

  È la stessa filosofia di Piccirillo e Cipriano: hosting condiviso economico, nessun database, superficie d'attacco minima.
- **Struttura**:
  ```
  viola-home-design-sito/
    PROMPT.md  README.md
    src/        pagine, partial, css, js, config.json,
                data/ (orari, occasioni, recensioni, vetrina, faq, avvisi).json
    sito/       output pronto da caricare
    tools/      build.mjs, immagini.mjs, mappa-statica.mjs, check.mjs (link, contrasti, JSON-LD)
    sorgenti/   logo, foto social, originali del cliente
    anteprime/  screenshot mobile/desktop
  ```
- **CSS**:
  - un solo file con custom properties e `@layer reset, base, components, utilities`;
  - container queries per le card.
- **JS**: moduli piccoli, tutti in progressive enhancement:
  - stato aperto/chiuso;
  - hero (nastro, crossfade, confetti);
  - configuratore;
  - carosello recensioni;
  - galleria e lightbox;
  - consenso;
  - menu;
  - barra mobile;
  - reveal.
- **Sicurezza** (`.htaccess` + meta):
  - HTTPS forzato, con canonical non-www (o www, da decidere col dominio);
  - **CSP stretta**: `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; frame-src https://www.google.com; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'; upgrade-insecure-requests`;
  - **niente script o stili inline**, oppure con hash calcolato dal build;
  - se si attivano GA4 o Pixel, il build aggiunge i domini necessari;
  - HSTS (1 anno), X-Content-Type-Options, Referrer-Policy `strict-origin-when-cross-origin`;
  - Permissions-Policy (camera, microfono, geolocalizzazione e pagamenti disattivati), COOP;
  - niente directory listing, blocco dei dotfile, `/.well-known/security.txt`;
  - cache lunga per gli asset con hash nel nome, compressione Brotli o gzip.
- **Redirect**: `/recensione` → link di recensione di Google (302), `/www` → canonical. Il vecchio dominio non ha storico da recuperare.
- **Anteprima**: il pannello preview non legge iCloud. Si lavora con un mirror in scratchpad (`rsync`) e una config `viola-dev` in `.claude/launch.json`, come per gli altri siti.

---

## 16. Criteri di accettazione (verificati, non dichiarati)

- [ ] Lighthouse mobile: Performance ≥ 95, Accessibilità 100, Best Practices 100, SEO 100 su Home, Bomboniere matrimonio, Recensioni e Contatti
- [ ] Hero a 375×667: arco con badge 5,0, chip, H1 e CTA primaria visibili al primo schermo. Animazione fluida a 60fps, statica con reduced-motion
- [ ] Nessuno scroll orizzontale da 320 a 1440px; screenshot salvati in `anteprime/` (375, 390, 768, 1440)
- [ ] Configuratore:
  - [ ] completabile solo da tastiera e con screen reader (ruoli, `aria-live` sul riepilogo);
  - [ ] il messaggio WhatsApp è leggibile e corretto (testato su `wa.me`);
  - [ ] la data "ordina entro" è corretta, anche a cavallo di mese o anno e con eventi a meno di 30 giorni;
  - [ ] i parametri URL preimpostano il wizard.
- [ ] Recensioni:
  - [ ] testi identici alla fonte;
  - [ ] riepilogo calcolato dal JSON;
  - [ ] nota di trasparenza presente;
  - [ ] nessun `aggregateRating`/`Review` nel JSON-LD.
- [ ] **Nessuna richiesta a domini terzi al caricamento** (verificato nel pannello rete)
- [ ] Maps si carica solo dopo il consenso, e la scelta resta salvata
- [ ] Il banner compare solo con GA4 o Pixel configurati (test con un ID finto); Accetta e Rifiuta hanno pari evidenza; "Preferenze cookie" funziona
- [ ] CSP attiva senza errori in console
- [ ] Header di sicurezza documentati nel README (verificati con curl, se il server di anteprima li supporta)
- [ ] Sito leggibile e navigabile con JS disattivato
- [ ] JSON-LD valido, un solo H1 per pagina, alt su tutte le immagini, contrasti AA verificati da `tools/check.mjs`
- [ ] Tutti i link `tel:`, `wa.me`, `mailto:` e Maps funzionanti
- [ ] Barra mobile corretta e mai sovrapposta
- [ ] Tutti i `[DA CONFERMARE]` elencati nel README; nessun prezzo, marchio od occasione inventati

---

## 17. Fasi di esecuzione

0. **Raccolta**:
   - leggere su Google Maps (con il browser) le **10 recensioni complete**, con data e risposte della titolare, e salvarle in `src/data/recensioni.json`;
   - con l'OK di Christian, salvare le foto migliori da FB/IG in `sorgenti/social/`;
   - recuperare il logo alla risoluzione più alta disponibile e il Place ID di Google.
1. **Fondamenta e hero**:
   - logo SVG, token, font, header e menu;
   - **hero con nastro, arco e confetti**;
   - barra mobile;
   - screenshot a 375 e 1440, poi revisione e correzione **prima di andare avanti**.
2. **Home completa**: tutte le sezioni del §7, **configuratore** (§8) e **recensioni** (§9), con i dati in `src/data/*.json`.
3. **Pagine interne** del §5: hub bomboniere e occasioni attive, lista nozze, casa e regali, recensioni, chi siamo, contatti, FAQ.
4. **Legale e tecnica**:
   - consent manager, privacy, cookie e note legali (§12);
   - JSON-LD, sitemap, llms.txt, robots e manifest;
   - OG image, `.htaccess` con CSP e header, 404, `/recensione`.
5. **QA** contro il §16, poi:
   - README (dati con fonti, da confermare, pubblicazione, aggiornamento di recensioni, vetrina e avvisi, azioni fuori dal sito, domande al cliente);
   - zip `viola-home-design-sito-da-caricare.zip`.
6. *(Opzionale, se il cliente vuole aggiornare la vetrina da sé)*:
   - pannello `/gestione` in PHP+SQLite sul modello di Appia Cars, per vetrina, avvisi e recensioni;
   - caricamento foto da mobile con conversione WebP, CSRF e throttling sul login.

---

## 18. Domande da girare al negozio (da riportare nel README)

1. **Civico esatto** (298 o 300) e orari completi:
   - il pomeriggio apre alle 16:00 o alle 16:30?
   - il lunedì mattina è chiuso?
   - la domenica prima di Natale apre?
   - quando sono le chiusure estive?
2. Il 334 981 8211 è su **WhatsApp** (Business)? Chi risponde?
3. **Occasioni** trattate: battesimo, nascita, comunione, cresima, laurea, anniversari?
4. **Fasce di prezzo** reali delle bomboniere (oltre al "da 3 €") e degli extra: confezione, segnaposto, partecipazioni.
5. **Lista nozze**:
   - come funziona per gli sposi e per gli invitati (in negozio, a distanza, bonifico)?
   - c'è una lista consultabile?
   - quanto dura?
6. **Consegna a domicilio**: zone e costi. **Spedizioni**: corriere, tempi, costi indicativi.
7. **Marchi** trattati: confetti, porcellane, candele, casalinghi. Si possono nominare?
8. **Titolare**:
   - nome e cognome;
   - consenso a nominarla e a usare una sua foto;
   - da quanti anni è aperto il negozio?
9. **Foto originali** senza watermark e disponibilità per uno shooting.
10. Logo originale vettoriale (chi l'ha realizzato? c'è il file dell'insegna?).
11. **Dati legali**: ragione sociale, P.IVA, sede legale, PEC, REA.
12. Parcheggio, accessibilità dell'ingresso, metodi di pagamento.
13. Accesso al **Google Business Profile** e alla pagina Facebook come amministratore, e OK alla **registrazione del dominio** violahomedesign.it a loro nome.
14. Eventi stagionali da comunicare (Natale, San Valentino, Festa della mamma, stagione delle comunioni) con le date.
