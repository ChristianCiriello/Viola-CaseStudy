// Home: hero «Il nastro viola» e tutte le sezioni del PROMPT §7, nell'ordine.
import { eroe, SLIDE, SIZES_EROE } from '../lib/eroe.mjs';
import { precaricaFoto } from '../lib/ui.mjs';
import { sezioneOccasioni, sezioneConfiguratore, sezioneListaNozze, sezioneIdeeRegalo, sezionePercheETempi, divisore } from '../lib/sezioni-negozio.mjs';
import { sezioneRecensioni, sezioneChiSiamo, sezioneFaq, sezioneDove, sezioneInstagram, sezioneChiusura, barraAvvisi } from '../lib/sezioni-fiducia.mjs';

export const meta = {
  percorso: '/',
  nav: 'home',
  classe: 'pagina-home',
  titolo: 'Viola Home Design · Bomboniere, Lista Nozze e Regali a Casagiove (Caserta)',
  titoloOg: 'Viola Home Design · Bomboniere e regali che si ricordano',
  descrizione: 'Bomboniere per matrimonio, battesimo e comunione, liste nozze e idee regalo all’uscita A1 Caserta Nord. 5,0 su Google. Consulenza per ogni budget. Tel. 334 981 8211.',
  testa: precaricaFoto(SLIDE[0].nome, SIZES_EROE),
};

export default () => [
  eroe(),
  barraAvvisi(),
  sezioneOccasioni(),
  sezioneConfiguratore(),
  sezioneRecensioni(),
  sezioneListaNozze(),
  divisore(),
  sezioneIdeeRegalo(),
  sezionePercheETempi(),
  sezioneChiSiamo(),
  sezioneFaq(),
  sezioneDove(),
  sezioneInstagram(),
  sezioneChiusura(),
].join('\n');
