// Viola Home Design — interazioni. Progressive enhancement: senza JS il sito resta completo.
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const ridotto = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const puntatoreFine = matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* ── orari: stato «aperto ora» calcolato sull'ora di Roma ── */
  const NOMI = ['', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'];
  const minuti = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
  const ora = (hhmm) => hhmm.replace(/^0/, '');
  function adessoRoma() {
    const parti = new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Rome', weekday: 'short', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(new Date());
    const v = (t) => parti.find((p) => p.type === t).value;
    return { giorno: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(v('weekday')) + 1, min: Number(v('hour')) * 60 + Number(v('minute')) };
  }
  function statoNegozio(orari) {
    const { giorno, min } = adessoRoma();
    const oggi = orari[giorno] || [];
    for (const [a, b] of oggi) {
      if (min >= minuti(a) && min < minuti(b)) {
        const resta = minuti(b) - min;
        return { aperto: true, testo: resta <= 30 ? `Aperto ora · chiude tra ${resta} min` : `Aperto ora · fino alle ${ora(b)}` };
      }
    }
    for (const [a] of oggi) if (min < minuti(a)) return { aperto: false, testo: `Chiuso ora · riapre alle ${ora(a)}` };
    for (let i = 1; i <= 7; i++) {
      const g = ((giorno - 1 + i) % 7) + 1;
      const f = orari[g] || [];
      if (f.length) return { aperto: false, testo: `Chiuso ora · riapre ${i === 1 ? 'domani' : NOMI[g]} alle ${ora(f[0][0])}` };
    }
    return null;
  }
  function aggiornaStato() {
    for (const el of $$('[data-stato]')) {
      const s = statoNegozio(JSON.parse(el.dataset.orari));
      if (!s) continue;
      el.querySelector('[data-stato-testo]').textContent = s.testo;
      el.classList.toggle('stato--aperto', s.aperto);
      el.hidden = false;
    }
    for (const el of $$('[data-oggi][data-orari]')) {
      const s = statoNegozio(JSON.parse(el.dataset.orari));
      if (s) el.querySelector('span').textContent = s.testo;
    }
  }
  aggiornaStato();
  setInterval(aggiornaStato, 60_000);

  /* ── vetrina ad arco: le foto 2–4 arrivano dopo il caricamento, poi dissolvenza ogni 5 s ── */
  function vetrina() {
    const box = $('[data-vetrina]');
    if (!box) return;
    const foto = $$('.vetrina__foto', box);
    const etichette = JSON.parse(box.dataset.etichette || '[]');
    const cartellino = $('.cartellino', box);
    const testo = $('[data-etichetta]', box);
    const carica = () => {
      for (const p of $$('picture[data-differita]', box)) {
        for (const s of $$('source', p)) { s.srcset = s.dataset.srcset; s.removeAttribute('data-srcset'); }
        const img = $('img', p);
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
        p.removeAttribute('data-differita');
      }
    };
    const dopoIlCaricamento = () => ('requestIdleCallback' in window ? requestIdleCallback(carica, { timeout: 2500 }) : setTimeout(carica, 800));
    if (document.readyState === 'complete') dopoIlCaricamento(); else addEventListener('load', dopoIlCaricamento, { once: true });
    if (ridotto || foto.length < 2) return;

    let i = 0;
    let visibile = true;
    new IntersectionObserver(([e]) => { visibile = e.isIntersecting; }).observe(box);
    setInterval(() => {
      if (!visibile || document.hidden) return;
      const n = (i + 1) % foto.length;
      const img = $('img', foto[n]);
      if (!img.complete || !img.naturalWidth) return; // la prossima foto non è ancora pronta: riprovo al giro dopo
      foto[i].classList.remove('vetrina__foto--attiva');
      foto[n].classList.add('vetrina__foto--attiva');
      i = n;
      if (cartellino && testo && etichette[n]) {
        cartellino.classList.add('cartellino--cambia');
        setTimeout(() => { testo.textContent = etichette[n]; cartellino.classList.remove('cartellino--cambia'); }, 350);
      }
    }, 5000);
  }
  vetrina();

  /* ── citazioni a rotazione ── */
  const citazioni = $$('[data-citazioni] .citazione');
  if (citazioni.length > 1 && !ridotto) {
    let c = 0;
    setInterval(() => {
      if (document.hidden) return;
      citazioni[c].classList.remove('citazione--attiva');
      c = (c + 1) % citazioni.length;
      citazioni[c].classList.add('citazione--attiva');
    }, 6500);
  }

  /* ── hero: parallax dei confetti (puntatore) e lembi del fiocco che si muovono allo scroll ── */
  const eroe = $('[data-eroe]');
  if (eroe && !ridotto) {
    const confetti = $$('.confetto', eroe).map((el) => ({ el, p: Number(el.dataset.profondita || 1) }));
    let mx = 0, my = 0, x = 0, y = 0, s = 0, attivo = true, rq = 0;
    const disegna = () => {
      rq = 0;
      x += (mx - x) * 0.08;
      y += (my - y) * 0.08;
      const h = eroe.offsetHeight || 1;
      s = Math.min(1, Math.max(0, scrollY / h));
      eroe.style.setProperty('--s', s.toFixed(3));
      for (const c of confetti) c.el.style.transform = `translate3d(${(x * 16 * c.p).toFixed(2)}px, ${(y * 12 * c.p - s * 60 * c.p).toFixed(2)}px, 0)`;
      if (attivo && (Math.abs(mx - x) > 0.002 || Math.abs(my - y) > 0.002)) rq = requestAnimationFrame(disegna);
    };
    const chiedi = () => { if (!rq && attivo) rq = requestAnimationFrame(disegna); };
    new IntersectionObserver(([e]) => { attivo = e.isIntersecting; if (attivo) chiedi(); }).observe(eroe);
    if (puntatoreFine) {
      eroe.addEventListener('pointermove', (e) => {
        const r = eroe.getBoundingClientRect();
        mx = ((e.clientX - r.left) / r.width - 0.5) * 2;
        my = ((e.clientY - r.top) / r.height - 0.5) * 2;
        chiedi();
      }, { passive: true });
    }
    addEventListener('scroll', chiedi, { passive: true });
  }

  /* ── testata: ombra quando si scorre, si nasconde scendendo e ricompare risalendo ── */
  const testata = $('[data-testata]');
  const menu = $('#menu');
  if (testata) {
    let ultimo = scrollY, rt = 0;
    const aggiorna = () => {
      rt = 0;
      const y = scrollY;
      testata.classList.toggle('testata--scorsa', y > 8);
      const giu = y > ultimo + 4, su = y < ultimo - 4;
      if (giu && y > 160 && !menu?.open && !testata.contains(document.activeElement)) testata.classList.add('testata--nascosta');
      else if (su || y < 160) testata.classList.remove('testata--nascosta');
      ultimo = y;
    };
    addEventListener('scroll', () => { if (!rt) rt = requestAnimationFrame(aggiorna); }, { passive: true });
    aggiorna();
    testata.addEventListener('focusin', () => testata.classList.remove('testata--nascosta'));
  }

  /* ── menu mobile (dialog nativo) ── */
  const apri = $('[data-apri-menu]');
  if (menu && apri && typeof menu.showModal === 'function') {
    apri.addEventListener('click', () => { menu.showModal(); apri.setAttribute('aria-expanded', 'true'); });
    $('[data-chiudi-menu]', menu)?.addEventListener('click', () => menu.close());
    menu.addEventListener('close', () => { apri.setAttribute('aria-expanded', 'false'); apri.focus(); });
    menu.addEventListener('click', (e) => { if (e.target === menu) menu.close(); });
    // scorrimento verso il basso col dito, partendo dall'alto del foglio: chiude
    let y0 = null;
    menu.addEventListener('touchstart', (e) => { y0 = menu.scrollTop <= 0 ? e.touches[0].clientY : null; }, { passive: true });
    menu.addEventListener('touchend', (e) => { if (y0 !== null && e.changedTouches[0].clientY - y0 > 90) menu.close(); y0 = null; }, { passive: true });
    for (const a of $$('a', menu)) a.addEventListener('click', () => menu.close());
  }

  /* ── barra azioni mobile: compare quando i pulsanti della hero escono dallo schermo, sparisce sopra il piè di pagina ── */
  const barra = $('[data-barra]');
  if (barra) {
    const primo = $('.eroe__azioni') || $('main > :first-child');
    const piede = $('[data-piede]');
    let dopoEroe = !primo, suPiede = false;
    const aggiorna = () => barra.classList.toggle('barra-azioni--visibile', dopoEroe && !suPiede);
    if (primo) new IntersectionObserver(([e]) => { dopoEroe = !e.isIntersecting && e.boundingClientRect.top < 0; aggiorna(); }).observe(primo);
    if (piede) new IntersectionObserver(([e]) => { suPiede = e.isIntersecting; aggiorna(); }).observe(piede);
    aggiorna();
  }

  /* ── date (configuratore e «i tempi giusti») ── */
  const fmtData = new Intl.DateTimeFormat('it-IT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtBreve = new Intl.DateTimeFormat('it-IT', { day: 'numeric', month: 'long' });
  const daInput = (v) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const meno = (d, giorni) => new Date(d.getFullYear(), d.getMonth(), d.getDate() - giorni);
  const oggi = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
  // Ritorna { testo, urgente } per una data di festa, oppure null se manca.
  function scadenze(data, anticipo, pronto) {
    if (!data) return null;
    const giorni = Math.round((data - oggi()) / 86400000);
    if (giorni < 0) return { testo: 'La data è già passata: controlla di averla scritta bene.', urgente: true };
    if (giorni < anticipo) return { testo: `Mancano ${giorni} giorni: i tempi sono stretti. Scrivici subito e vediamo insieme cosa si può fare.`, urgente: true };
    return { testo: `Ordina entro ${fmtData.format(meno(data, anticipo))}. Di solito le bomboniere sono pronte verso il ${fmtBreve.format(meno(data, pronto))}.`, urgente: false };
  }
  const memoria = {
    leggi(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } },
    scrivi(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage non disponibile: pazienza */ } },
    togli(k) { try { localStorage.removeItem(k); } catch { /* */ } },
  };

  /* ── configuratore «Crea la tua bomboniera» ── */
  function configuratore() {
    const box = $('[data-conf]');
    if (!box) return;
    const C = JSON.parse(box.dataset.config);
    const CHIAVE = 'vhd_configuratore';
    const pannelli = $$('[data-passo]', box);
    const bottoniPasso = $$('[data-vai]', box);
    const avanti = $('[data-avanti]', box), indietro = $('[data-indietro]', box), errore = $('[data-errore]', box);
    const nastro = $('[data-avanzamento]', box);
    const pezzi = $('#conf-pezzi', box), data = $('#conf-data', box), nome = $('#conf-nome', box);
    const aiutoData = $('[data-scadenza]', box);
    let passo = 1, massimo = 1, daPuntatore = false;

    const stato = () => ({
      occasione: $('input[name=occasione]:checked', box)?.value || '',
      stile: $('input[name=stile]:checked', box)?.value || '',
      budget: $('input[name=budget]:checked', box)?.value || '',
      pezzi: pezzi.value, data: data.value, nome: nome.value.trim(),
      extra: $$('input[name=extra]:checked', box).map((i) => i.value),
    });
    const salva = () => memoria.scrivi(CHIAVE, { ...stato(), passo, massimo });
    const ripristina = (s) => {
      if (!s) return;
      for (const k of ['occasione', 'stile', 'budget']) if (s[k]) { const i = $(`input[name=${k}][value="${CSS.escape(s[k])}"]`, box); if (i) i.checked = true; }
      pezzi.value = s.pezzi || ''; data.value = s.data || ''; nome.value = s.nome || '';
      for (const i of $$('input[name=extra]', box)) i.checked = (s.extra || []).includes(i.value);
      massimo = Math.min(Math.max(s.massimo || 1, 1), 5);
    };

    function mostra(n, { focus = true } = {}) {
      passo = n;
      massimo = Math.max(massimo, n);
      for (const p of pannelli) p.hidden = Number(p.dataset.passo) !== n;
      bottoniPasso.forEach((b, i) => {
        const k = i + 1;
        b.disabled = k > massimo || k === n;
        b.classList.toggle('fatto', k < massimo && k !== n);
        if (k === Math.min(n, 4)) b.setAttribute('aria-current', 'step'); else b.removeAttribute('aria-current');
      });
      nastro.style.transform = `scaleX(${Math.min(n, 4) / 4})`;
      indietro.hidden = n === 1;
      indietro.textContent = n === 5 ? 'Modifica' : 'Indietro';
      avanti.hidden = n === 5;
      avanti.firstChild.textContent = n === 4 ? 'Vedi il riepilogo' : 'Avanti';
      errore.textContent = '';
      if (n === 5) riepilogo();
      if (focus) {
        const bersaglio = n === 5 ? $('[data-biglietto]', box) : $(`[data-passo="${n}"] legend`, box);
        bersaglio?.focus({ preventScroll: true });
        const r = box.getBoundingClientRect();
        if (r.top < 0 || r.top > innerHeight * 0.6) box.scrollIntoView({ behavior: ridotto ? 'auto' : 'smooth', block: 'start' });
      }
      salva();
    }
    const MANCA = { 1: 'Scegli un’occasione per continuare.', 2: 'Scegli uno stile (va bene anche «Consigliatemi voi»).', 3: 'Scegli una fascia di budget (o «Preferisco parlarne»).' };
    function valida(n) {
      const s = stato();
      const ok = n === 1 ? s.occasione : n === 2 ? s.stile : n === 3 ? s.budget : true;
      errore.textContent = ok ? '' : MANCA[n];
      return Boolean(ok);
    }
    avanti.addEventListener('click', () => { if (valida(passo)) mostra(passo + 1); });
    indietro.addEventListener('click', () => mostra(passo === 5 ? 4 : passo - 1));
    bottoniPasso.forEach((b) => b.addEventListener('click', () => mostra(Number(b.dataset.vai))));
    // scelta col dito o col mouse: si passa da soli al passo successivo (con la tastiera no, per non disorientare)
    box.addEventListener('pointerdown', () => { daPuntatore = true; setTimeout(() => { daPuntatore = false; }, 800); });
    box.addEventListener('change', (e) => {
      const t = e.target;
      if (t.type === 'radio') { errore.textContent = ''; if (daPuntatore && passo < 4) setTimeout(() => mostra(passo + 1), 260); }
      if (t === data) aggiornaData();
      salva();
    });
    box.addEventListener('input', (e) => { if (e.target === pezzi || e.target === nome) salva(); });
    for (const b of $$('[data-pezzi]', box)) b.addEventListener('click', () => {
      const v = Math.max(1, Math.min(2000, (parseInt(pezzi.value, 10) || 0) + Number(b.dataset.pezzi)));
      pezzi.value = v; salva();
    });
    function aggiornaData() {
      const s = scadenze(daInput(data.value), C.anticipo, C.pronto);
      aiutoData.textContent = s ? s.testo : '';
      aiutoData.classList.toggle('urgente', Boolean(s?.urgente));
    }

    function riepilogo() {
      const s = stato();
      const d = daInput(s.data);
      const voci = [
        ['Occasione', C.occasioni[s.occasione]],
        ['Stile', C.stili[s.stile]],
        ['Budget per bomboniera', C.budget[s.budget]],
        ['Quantità', s.pezzi ? `${s.pezzi} pezzi` : ''],
        ['Data della festa', d ? fmtData.format(d) : ''],
        ['Ti interessano anche', s.extra.map((x) => C.extra[x].toLowerCase()).join(', ')],
        ['Nome', s.nome],
      ].filter(([, v]) => v);
      const dl = $('[data-riepilogo]', box);
      dl.replaceChildren(...voci.map(([k, v]) => { const r = document.createElement('div'); const dt = document.createElement('dt'); const dd = document.createElement('dd'); dt.textContent = k; dd.textContent = v; r.append(dt, dd); return r; }));
      const sc = scadenze(d, C.anticipo, C.pronto);
      const scad = $('[data-scadenza-riepilogo]', box);
      scad.textContent = sc ? sc.testo : '';
      scad.classList.toggle('urgente', Boolean(sc?.urgente));
      const righe = voci.filter(([k]) => k !== 'Nome').map(([k, v]) => `• ${k}: ${v}`).join('\n');
      const firma = s.nome ? `\n\n${s.nome}` : '';
      const testoWa = `Buongiorno! Vorrei un consiglio per delle bomboniere.\n${righe}${firma}\n\n(dal configuratore del sito)`;
      const occ = C.occasioni[s.occasione] || 'la mia festa';
      $('[data-invia=wa]', box).href = `https://wa.me/${C.wa}?text=${encodeURIComponent(testoWa)}`;
      $('[data-invia=email]', box).href = `mailto:${C.email}?subject=${encodeURIComponent(`Richiesta bomboniere – ${occ}`)}&body=${encodeURIComponent(testoWa)}`;
      $('[data-invia=negozio]', box).href = `https://wa.me/${C.wa}?text=${encodeURIComponent(`Buongiorno, vorrei passare in negozio per scegliere le bomboniere (${occ.toLowerCase()}${d ? `, festa il ${fmtBreve.format(d)}` : ''}). Quando posso venire?${firma}`)}`;
    }
    $('[data-ricomincia]', box).addEventListener('click', () => {
      for (const i of $$('input', box)) { if (i.type === 'radio' || i.type === 'checkbox') i.checked = false; else i.value = ''; }
      memoria.togli(CHIAVE); massimo = 1; aggiornaData(); mostra(1);
    });

    // dalle card delle occasioni (o da un link ?occasione=…): occasione già scelta, si parte dallo stile
    const preseleziona = (id) => {
      const i = $(`input[name=occasione][value="${CSS.escape(id)}"]`, box);
      if (!i) return false;
      i.checked = true; massimo = Math.max(massimo, 2); mostra(2, { focus: false });
      return true;
    };
    ripristina(memoria.leggi(CHIAVE));
    aggiornaData();
    const daUrl = new URLSearchParams(location.search).get('occasione');
    if (!(daUrl && preseleziona(daUrl))) mostra(Math.min(memoria.leggi(CHIAVE)?.passo || 1, massimo), { focus: false });
    for (const a of $$('[data-scegli-occasione]')) a.addEventListener('click', (e) => {
      if (!preseleziona(a.dataset.scegliOccasione)) return;
      e.preventDefault();
      history.replaceState(null, '', `?occasione=${a.dataset.scegliOccasione}#configuratore`);
      box.scrollIntoView({ behavior: ridotto ? 'auto' : 'smooth', block: 'start' });
      setTimeout(() => $('[data-passo="2"] legend', box)?.focus({ preventScroll: true }), ridotto ? 0 : 500);
    });
  }
  configuratore();

  /* ── recensioni: «leggi tutto», carosello, barre ── */
  for (const t of $$('[data-testo-lungo]')) {
    const btn = t.parentElement.querySelector('[data-leggi-tutto]');
    if (t.scrollHeight > t.clientHeight + 4) {
      t.classList.add('lunga');
      btn.hidden = false;
      btn.addEventListener('click', () => { const aperta = t.classList.toggle('aperta'); btn.textContent = aperta ? 'Mostra meno' : 'Leggi tutto'; });
    }
  }
  for (const c of $$('[data-carosello]')) {
    const traccia = $('[data-carosello-traccia]', c);
    for (const b of $$('[data-carosello-passo]', c)) b.addEventListener('click', () => {
      const card = traccia.firstElementChild;
      const passo = card ? card.getBoundingClientRect().width + 16 : traccia.clientWidth;
      traccia.scrollBy({ left: Number(b.dataset.caroselloPasso) * passo, behavior: ridotto ? 'auto' : 'smooth' });
    });
  }
  for (const b of $$('.barra__piena[data-perc]')) b.style.width = `${b.dataset.perc}%`;

  /* ── vetrina idee regalo: filtri, «mostra tutte» su mobile, lightbox ── */
  function vetrinaRegali() {
    const gal = $('[data-galleria]');
    if (!gal) return;
    const voci = $$('.galleria__voce', gal);
    const filtri = $$('[data-filtro]');
    const piu = $('[data-mostra-tutto]');
    const LIMITE = matchMedia('(max-width: 639px)').matches ? 6 : Infinity;
    let filtro = 'tutto', tutte = false;
    const applica = () => {
      let n = 0;
      for (const v of voci) {
        const ok = filtro === 'tutto' || v.dataset.categoria === filtro;
        const dentro = ok && (tutte || filtro !== 'tutto' || n < LIMITE);
        if (ok) n++;
        if (v.hidden === dentro) { v.hidden = !dentro; if (dentro) { v.classList.remove('entra'); void v.offsetWidth; v.classList.add('entra'); } }
      }
      const nascoste = filtro === 'tutto' && !tutte ? Math.max(0, voci.length - LIMITE) : 0;
      piu.hidden = !nascoste;
      piu.textContent = `Mostra tutte le idee (${voci.length})`;
    };
    for (const f of filtri) f.addEventListener('click', () => {
      filtro = f.dataset.filtro;
      for (const g of filtri) g.setAttribute('aria-pressed', String(g === f));
      applica();
    });
    piu.addEventListener('click', () => { tutte = true; applica(); voci[LIMITE]?.querySelector('button')?.focus(); });
    applica();

    const lb = $('[data-lightbox]');
    const datiFoto = JSON.parse($('[data-vetrina-dati]').textContent);
    if (!lb || typeof lb.showModal !== 'function') return;
    const img = $('[data-lightbox-img]', lb);
    let corrente = 0;
    const visibili = () => voci.filter((v) => !v.hidden).map((v) => Number(v.dataset.indice));
    const apri = (i) => {
      corrente = i;
      const d = datiFoto[i];
      img.removeAttribute('src');
      img.width = d.w; img.height = d.h; img.alt = d.a;
      $('[data-lightbox-avif]', lb).srcset = d.avif;
      img.src = d.webp;
      $('[data-lightbox-cat]', lb).textContent = d.c;
      $('[data-lightbox-titolo]', lb).textContent = d.t;
      const v = visibili();
      $('[data-lightbox-conto]', lb).textContent = `${v.indexOf(i) + 1} di ${v.length}`;
      $('[data-lightbox-wa]', lb).href = `https://wa.me/${lb.dataset.wa}?text=${encodeURIComponent(`Buongiorno, ho visto sul sito «${d.t}»: vorrei qualche informazione.`)}`;
      if (!lb.open) lb.showModal();
    };
    const sposta = (passo) => { const v = visibili(); const k = v.indexOf(corrente); apri(v[(k + passo + v.length) % v.length]); };
    for (const b of $$('[data-apri-foto]', gal)) b.addEventListener('click', () => apri(Number(b.dataset.apriFoto)));
    for (const b of $$('[data-lightbox-passo]', lb)) b.addEventListener('click', () => sposta(Number(b.dataset.lightboxPasso)));
    $('[data-chiudi-lightbox]', lb).addEventListener('click', () => lb.close());
    lb.addEventListener('click', (e) => { if (e.target === lb) lb.close(); });
    lb.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') sposta(1); if (e.key === 'ArrowLeft') sposta(-1); });
    lb.addEventListener('close', () => $(`[data-apri-foto="${corrente}"]`, gal)?.focus());
    let x0 = null;
    lb.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', (e) => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 50) sposta(dx < 0 ? 1 : -1); x0 = null; }, { passive: true });
  }
  vetrinaRegali();

  /* ── i tempi giusti: «ordina entro…» ── */
  for (const box of $$('[data-calcola-tempi]')) {
    const input = $('input', box), esito = $('[data-tempi-esito]', box), wa = $('[data-tempi-wa]', box);
    const base = wa.href.split('?')[0];
    input.addEventListener('change', () => {
      const d = daInput(input.value);
      const s = scadenze(d, Number(box.dataset.anticipo), Number(box.dataset.pronto));
      if (!s) return;
      esito.textContent = s.testo;
      esito.classList.toggle('urgente', s.urgente);
      wa.hidden = false;
      wa.href = `${base}?text=${encodeURIComponent(`Buongiorno, vorrei organizzare le bomboniere per una festa ${fmtData.format(d)}.`)}`;
    });
  }

  /* ── consenso (base): per ora solo «contenuti esterni» (mappa Google). La gestione completa arriva con il banner ── */
  const consenso = {
    leggi() { try { return JSON.parse(decodeURIComponent((document.cookie.match(/(?:^|; )vhd_consenso=([^;]*)/) || [])[1] || 'null')) || {}; } catch { return {}; } },
    salva(cat, valore) {
      const c = { ...consenso.leggi(), v: 1, data: new Date().toISOString().slice(0, 10), [cat]: valore };
      document.cookie = `vhd_consenso=${encodeURIComponent(JSON.stringify(c))}; Max-Age=${60 * 60 * 24 * 182}; Path=/; SameSite=Lax${location.protocol === 'https:' ? '; Secure' : ''}`;
    },
  };
  window.vhdConsenso = consenso;

  /* ── mappa: immagine statica locale; la mappa Google si carica solo col consenso ── */
  for (const m of $$('[data-mappa]')) {
    const carica = () => {
      if (m.classList.contains('mappa--caricata')) return;
      const f = document.createElement('iframe');
      f.src = m.dataset.embed; f.title = 'Mappa Google: Viola Home Design a Casagiove'; f.loading = 'lazy'; f.referrerPolicy = 'no-referrer-when-downgrade';
      m.append(f); m.classList.add('mappa--caricata');
    };
    $('[data-carica-mappa]', m).addEventListener('click', () => { consenso.salva('esterni', true); carica(); });
    if (consenso.leggi().esterni) new IntersectionObserver(([e], o) => { if (e.isIntersecting) { carica(); o.disconnect(); } }, { rootMargin: '200px' }).observe(m);
  }

  /* ── avvisi a tempo: spariscono dopo la data «al» anche se il sito non viene rigenerato ── */
  const iso = new Date().toISOString().slice(0, 10);
  for (const a of $$('.avviso[data-al]')) if ((a.dataset.al && a.dataset.al < iso) || (a.dataset.dal && a.dataset.dal > iso)) a.hidden = true;

  /* ── comparsa delle sezioni allo scroll ── */
  const rivela = $$('.rivela');
  if ('IntersectionObserver' in window && !ridotto) {
    const io = new IntersectionObserver((voci) => { for (const v of voci) if (v.isIntersecting) { v.target.classList.add('visibile'); io.unobserve(v.target); } }, { rootMargin: '0px 0px -10% 0px' });
    rivela.forEach((el) => io.observe(el));
  } else rivela.forEach((el) => el.classList.add('visibile'));

})();
