#!/bin/sh
# Doppio clic: rigenera il sito e lo apre nel browser su http://127.0.0.1:8899
# Per fermarlo: chiudi questa finestra del Terminale (oppure Ctrl+C).
cd "$(dirname "$0")" || exit 1
PORTA=8899

# se un'anteprima precedente è ancora accesa sulla stessa porta, la spengo
VECCHIO=$(lsof -ti tcp:$PORTA 2>/dev/null)
[ -n "$VECCHIO" ] && kill $VECCHIO 2>/dev/null && sleep 0.5

echo "→ Genero il sito…"
node tools/build.mjs || { echo "✗ Errore nella generazione: vedi sopra."; read -r _; exit 1; }

echo "→ Anteprima su http://127.0.0.1:$PORTA  (Ctrl+C o chiudi la finestra per fermarla)"
(sleep 1; open "http://127.0.0.1:$PORTA") &
node tools/server.mjs sito $PORTA
